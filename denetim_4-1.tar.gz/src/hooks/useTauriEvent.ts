import { useEffect, useRef } from 'react';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

export function useTauriEvent<T>(eventName: string, handler: (event: T) => void) {
  const savedHandler = useRef(handler);

  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    let unlisten: UnlistenFn | undefined;
    let isMounted = true;

    let isQueued = false;
    let latestPayload: T | null = null;

    listen<T>(eventName, (event) => {
      if (!isMounted) return;
      latestPayload = event.payload;
      if (!isQueued) {
        isQueued = true;
        requestAnimationFrame(() => {
          isQueued = false;
          if (isMounted && latestPayload !== null) {
            savedHandler.current(latestPayload);
          }
        });
      }
    }).then((unlistenFn) => {
      unlisten = unlistenFn;
    });

    return () => {
      isMounted = false;
      if (unlisten) {
        unlisten();
      }
    };
  }, [eventName]);
}
