import { useState } from 'react';
import { GlassPanel } from './ui/GlassPanel';
import { NeonButton } from './ui/NeonButton';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Play, Square, Users, Zap } from 'lucide-react';
import { Icon } from './ui/Icon';
import { useMicroInteractions } from '../hooks/useMicroInteractions';

interface ArenaAgent {
  id: string;
  name: string;
  role: string;
  color: string;
}

const DUMMY_AGENTS: ArenaAgent[] = [
  { id: '1', name: 'Black Ice', role: 'Critic', color: 'var(--forge-accent)' },
  { id: '2', name: 'Neon Rain', role: 'Creator', color: 'var(--forge-danger)' },
  { id: '3', name: 'Code Wizard', role: 'Architect', color: 'var(--forge-success)' },
];

export function ArenaView() {
  const [isRunning, setIsRunning] = useState(false);
  const [topic, setTopic] = useState('');
  const [messages, setMessages] = useState<{agentId: string, content: string}[]>([]);
  const { playClickSound, playGlitchSound } = useMicroInteractions();

  const handleStart = () => {
    if (!topic.trim()) return;
    playGlitchSound();
    setIsRunning(true);
    setMessages([{ agentId: 'system', content: `INITIATING ROUNDTABLE: ${topic}` }]);
    
    // Simulate agents talking
    setTimeout(() => {
      setMessages(prev => [...prev, { agentId: '2', content: "I'll start. This topic requires out-of-the-box thinking. What if we inverse the paradigm?" }]);
    }, 2000);

    setTimeout(() => {
      setMessages(prev => [...prev, { agentId: '1', content: "Invalid approach. Inversing the paradigm introduces O(N^2) complexity. We must optimize." }]);
    }, 4500);
  };

  const handleStop = () => {
    playClickSound();
    setIsRunning(false);
  };

  return (
    <div className="flex flex-col h-full bg-forge-bg overflow-hidden p-6 gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-orbitron font-bold text-forge-text drop-shadow-[0_0_10px_var(--forge-text)] tracking-wider">ARENA</h1>
          <p className="text-forge-text-muted font-mono text-sm tracking-widest uppercase mt-1">Multi-Agent Deliberation Engine</p>
        </div>
        
        <GlassPanel intensity="low" className="flex items-center gap-4 px-4 py-2 border-forge-border-subtle">
          <div className="flex items-center gap-2">
            <Icon icon={Users} className="text-forge-accent" size={18} />
            <span className="font-mono text-forge-text font-bold text-sm">3 AGENTS</span>
          </div>
          <div className="w-px h-4 bg-forge-border" />
          <div className="flex items-center gap-2">
            <Icon icon={Zap} className="text-forge-warning" size={18} />
            <span className="font-mono text-forge-text font-bold text-sm">AUTO-RESOLVE</span>
          </div>
        </GlassPanel>
      </div>

      <div className="flex gap-6 h-full min-h-0">
        {/* Arena Configuration Sidebar */}
        <div className="w-80 flex flex-col gap-4">
          <GlassPanel className="p-4 flex flex-col gap-4 border-forge-accent/20 flex-1">
            <div className="font-mono text-xs text-forge-accent tracking-widest uppercase font-bold border-b border-forge-border pb-2 mb-2">
              Configuration
            </div>
            
            <div className="flex flex-col gap-2">
              <label className="font-mono text-[10px] text-forge-text-muted uppercase tracking-wider">Debate Topic</label>
              <textarea 
                className="w-full bg-forge-surface-2 border border-forge-border rounded-lg p-3 text-sm font-mono text-forge-text focus:outline-none focus:border-forge-accent transition-colors resize-none h-32"
                placeholder="Enter a topic for the agents to discuss..."
                value={topic}
                onChange={e => setTopic(e.target.value)}
                disabled={isRunning}
              />
            </div>

            <div className="flex flex-col gap-2 flex-1">
              <label className="font-mono text-[10px] text-forge-text-muted uppercase tracking-wider">Active Participants</label>
              <div className="flex flex-col gap-2">
                {DUMMY_AGENTS.map(agent => (
                  <div key={agent.id} className="flex items-center gap-3 p-2 rounded border border-forge-border bg-forge-surface-2/50">
                    <div className="w-2 h-2 rounded-full shadow-[0_0_5px_currentColor]" style={{ color: agent.color, backgroundColor: agent.color }} />
                    <div className="flex flex-col">
                      <span className="font-mono text-sm text-forge-text font-bold">{agent.name}</span>
                      <span className="font-mono text-[10px] text-forge-text-muted uppercase tracking-wider">{agent.role}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-auto">
              {isRunning ? (
                <NeonButton variant="danger" className="w-full" onClick={handleStop}>
                  <Icon icon={Square} size={16} className="inline-block mr-2 -mt-0.5" />
                  Halt Simulation
                </NeonButton>
              ) : (
                <NeonButton variant="accent" className="w-full" onClick={handleStart} disabled={!topic.trim()}>
                  <Icon icon={Play} size={16} className="inline-block mr-2 -mt-0.5" />
                  Initialize Arena
                </NeonButton>
              )}
            </div>
          </GlassPanel>
        </div>

        {/* Main Arena Output */}
        <GlassPanel className="flex-1 flex flex-col border-forge-border-subtle relative overflow-hidden">
          {/* Holographic grid background */}
          <div className="absolute inset-0 pointer-events-none opacity-5" 
            style={{ backgroundImage: 'linear-gradient(var(--forge-border) 1px, transparent 1px), linear-gradient(90deg, var(--forge-border) 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
          />

          <div className="flex-1 p-6 overflow-y-auto custom-scrollbar flex flex-col gap-4 relative z-10">
            {messages.length === 0 ? (
              <div className="m-auto flex flex-col items-center justify-center text-forge-text-muted opacity-50">
                <Icon icon={Users} size={48} className="mb-4" />
                <p className="font-mono tracking-widest uppercase">Awaiting Topic Initialization</p>
              </div>
            ) : (
              <AnimatePresence>
                {messages.map((msg, i) => {
                  if (msg.agentId === 'system') {
                    return (
                      <motion.div 
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-center my-4"
                      >
                        <span className="inline-block px-4 py-1 border border-forge-accent/30 bg-forge-accent/10 text-forge-accent font-mono text-xs tracking-widest uppercase rounded">
                          {msg.content}
                        </span>
                      </motion.div>
                    );
                  }

                  const agent = DUMMY_AGENTS.find(a => a.id === msg.agentId);
                  if (!agent) return null;

                  const isRight = parseInt(agent.id) % 2 === 0;

                  return (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: isRight ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`flex w-full ${isRight ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] flex flex-col gap-1 ${isRight ? 'items-end' : 'items-start'}`}>
                        <div className="flex items-center gap-2 px-1">
                          {!isRight && <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: agent.color, boxShadow: `0 0 5px ${agent.color}` }} />}
                          <span className="font-mono text-[10px] uppercase tracking-widest font-bold" style={{ color: agent.color }}>{agent.name}</span>
                          {isRight && <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: agent.color, boxShadow: `0 0 5px ${agent.color}` }} />}
                        </div>
                        <div className="p-3 bg-forge-surface-2 border border-forge-border-subtle rounded-xl text-forge-text font-mono text-sm">
                          {msg.content}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}
            
            {isRunning && messages.length > 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 text-forge-text-muted mt-4"
              >
                <div className="w-2 h-2 rounded-full bg-forge-accent animate-ping" />
                <span className="font-mono text-xs tracking-widest uppercase">Agents deliberating...</span>
              </motion.div>
            )}
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
