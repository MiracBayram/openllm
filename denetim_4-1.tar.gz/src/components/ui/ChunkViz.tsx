import { motion } from 'framer-motion';
import { GlassPanel } from './GlassPanel';
import { Database, FileText, Zap } from 'lucide-react';
import { Icon } from './Icon';

interface ChunkVizProps {
  chunks: string[];
  relevanceScores?: number[];
  query?: string;
}

export function ChunkViz({ chunks, relevanceScores, query }: ChunkVizProps) {
  if (!chunks || chunks.length === 0) return null;

  return (
    <div className="flex flex-col gap-4 w-full p-4">
      <div className="flex items-center justify-between border-b border-forge-border-subtle pb-2">
        <div className="flex items-center gap-2">
          <Icon icon={Database} className="text-forge-accent animate-pulse" size={16} />
          <span className="font-mono text-xs uppercase tracking-widest text-forge-accent font-bold">Vector DB Retrieval</span>
        </div>
        {query && (
          <div className="text-xs font-mono text-forge-text-muted bg-forge-surface px-2 py-1 rounded border border-forge-border truncate max-w-[200px]">
            Q: {query}
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-3">
        {chunks.map((chunk, idx) => {
          const score = relevanceScores ? relevanceScores[idx] : Math.random() * 0.5 + 0.4;
          const isHighRelevance = score > 0.8;
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: idx * 0.1, type: 'spring', stiffness: 300, damping: 25 }}
              className="flex-1 min-w-[250px]"
            >
              <GlassPanel 
                intensity="low" 
                className={`p-3 border-l-2 relative overflow-hidden group ${
                  isHighRelevance ? 'border-l-forge-success' : 'border-l-forge-accent'
                }`}
              >
                {/* Background scanning effect */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-b from-transparent via-forge-accent/10 to-transparent -translate-y-full opacity-0 group-hover:opacity-100"
                  animate={{ translateY: ['-100%', '200%'] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                />

                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 text-xs font-mono text-forge-text-muted uppercase">
                    <Icon icon={FileText} size={12} />
                    <span>Chunk {idx + 1}</span>
                  </div>
                  <div className={`flex items-center gap-1 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                    isHighRelevance ? 'bg-forge-success/20 text-forge-success' : 'bg-forge-accent/20 text-forge-accent'
                  }`}>
                    {isHighRelevance && <Icon icon={Zap} size={10} />}
                    <span>{(score * 100).toFixed(1)}% MATCH</span>
                  </div>
                </div>
                
                <p className="text-sm text-forge-text font-mono line-clamp-3 leading-relaxed">
                  {chunk}
                </p>
                
                {/* Hex dump decoration */}
                <div className="mt-2 pt-2 border-t border-forge-border-subtle text-[8px] font-mono text-forge-text-muted/30 break-all opacity-0 group-hover:opacity-100 transition-opacity">
                  {Array.from({length: 8}).map(() => Math.floor(Math.random() * 255).toString(16).padStart(2, '0')).join(' ')}
                </div>
              </GlassPanel>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
