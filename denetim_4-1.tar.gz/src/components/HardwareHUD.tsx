import { useEffect, useRef, useMemo, useState } from 'react';
import { useHardwareLerp } from '../hooks/useHardwareLerp';
import { useTelemetryHUD } from '../store/telemetryStore';
import { useChatStore } from '../store/chatStore';

// === 1. RADIAL GAUGE (SVG) ===
function RadialGauge({ value, max, label, subLabel, colorHex }: { value: number, max: number, label: string, subLabel: string, colorHex: string }) {
  const normalized = Math.min(Math.max(value / max, 0), 1);
  const radius = 30;
  const circumference = 2 * Math.PI * radius * 0.75; // 270 degrees
  const dashoffset = circumference * (1 - normalized);

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-[80px] h-[80px] flex items-center justify-center">
        <svg className="absolute inset-0 w-full h-full transform rotate-135" viewBox="0 0 80 80">
          <circle 
            cx="40" cy="40" r={radius} 
            fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="6"
            strokeDasharray={`${circumference} ${2 * Math.PI * radius}`}
            strokeLinecap="round"
          />
          {normalized > 0 && (
            <circle 
              cx="40" cy="40" r={radius} 
              fill="none" stroke={colorHex} strokeWidth="4"
              strokeDasharray={`${circumference} ${2 * Math.PI * radius}`}
              strokeDashoffset={dashoffset}
              strokeLinecap="round"
              className="transition-all duration-300 ease-out drop-shadow-[0_0_8px_currentColor]"
            />
          )}
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-[14px] font-bold" style={{ color: colorHex, textShadow: `0 0 8px ${colorHex}` }}>
            {Math.round(normalized * 100)}%
          </span>
        </div>
      </div>
      <span className="text-[10px] text-forge-text-secondary mt-1 tracking-widest">{label}</span>
      <span className="text-[9px] text-forge-text-muted font-mono">{subLabel}</span>
    </div>
  );
}

// === 2. SCROLL GRAPH (CANVAS) ===
function ScrollGraph({ value, label, unit, colorHex }: { value: number, label: string, unit: string, colorHex: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const historyRef = useRef<number[]>([]);
  const capacity = 60; // frames

  useEffect(() => {
    historyRef.current.push(value);
    if (historyRef.current.length > capacity) historyRef.current.shift();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, w, h);

    const maxVal = Math.max(...historyRef.current, 10);
    
    // Draw Grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    if (historyRef.current.length < 2) return;

    // Draw Line
    ctx.beginPath();
    historyRef.current.forEach((val, i) => {
      const x = (i / (capacity - 1)) * w;
      const y = h - (val / maxVal) * h;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });

    ctx.strokeStyle = colorHex;
    ctx.lineWidth = 1.5;
    ctx.shadowBlur = 4;
    ctx.shadowColor = colorHex;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw Fill
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.fillStyle = `${colorHex}15`; // ~10% opacity
    ctx.fill();

  }, [value, colorHex]);

  return (
    <div className="flex flex-col gap-1 w-full border border-forge-border rounded bg-forge-surface-2 p-1">
      <div className="flex justify-between items-center px-1">
        <span className="text-[9px] text-forge-text-secondary tracking-widest uppercase">{label}</span>
        <span className="text-[10px] font-bold" style={{ color: colorHex, textShadow: `0 0 5px ${colorHex}` }}>
          {value.toFixed(1)} <span className="text-[9px] text-forge-text-muted">{unit}</span>
        </span>
      </div>
      <canvas ref={canvasRef} className="w-full h-[40px]" />
    </div>
  );
}

// === 3. METRIC BAR (HTML) ===
function MetricBar({ label, valueStr, progress, colorHex }: { label: string, valueStr: string, progress: number, colorHex: string }) {
  return (
    <div className="flex flex-col gap-1 w-full">
      <div className="flex justify-between items-center">
        <span className="text-[9px] text-forge-text-secondary tracking-widest uppercase">{label}</span>
        <span className="text-[10px] font-mono text-forge-text-muted">{valueStr}</span>
      </div>
      <div className="w-full h-[6px] bg-forge-surface-3 rounded-full overflow-hidden relative">
        <div 
          className="absolute top-0 left-0 h-full rounded-full transition-all duration-300"
          style={{ 
            width: `${Math.min(Math.max(progress * 100, 0), 100)}%`, 
            backgroundColor: colorHex,
            boxShadow: `0 0 8px ${colorHex}`
          }}
        />
      </div>
    </div>
  );
}

// === 4. CELL GRID (CANVAS) ===
function CellGrid({ used, total, label, colorHex }: { used: number, total: number, label: string, colorHex: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, w, h);

    const cols = 32;
    const rows = Math.ceil(total / cols);
    const cellW = w / cols;
    const cellH = h / rows;
    const size = Math.min(cellW, cellH, 6); // Max size 6px
    
    // Center the grid
    const startX = (w - (size * cols)) / 2;
    const startY = (h - (size * rows)) / 2;

    for (let i = 0; i < total; i++) {
      const row = Math.floor(i / cols);
      const col = i % cols;
      const x = startX + col * size;
      const y = startY + row * size;

      ctx.beginPath();
      ctx.roundRect(x + 0.5, y + 0.5, size - 1, size - 1, 1);
      
      if (i < used) {
        ctx.fillStyle = colorHex;
        ctx.shadowBlur = 4;
        ctx.shadowColor = colorHex;
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.shadowBlur = 0;
      }
      ctx.fill();
    }
  }, [used, total, colorHex]);

  return (
    <div className="flex flex-col gap-1 w-full">
      <div className="flex justify-between items-center">
        <span className="text-[9px] text-forge-text-secondary tracking-widest uppercase">{label}</span>
        <span className="text-[10px] font-mono text-forge-text-muted">{used} / {total}</span>
      </div>
      <canvas ref={canvasRef} className="w-full h-[64px]" />
    </div>
  );
}

// === MAIN COMPONENT ===
export function HardwareHUD() {
  const { vramUsedMb, ramUsedMb } = useHardwareLerp();
  const { tps } = useTelemetryHUD();
  const ttftMs = (useTelemetryHUD() as any).ttftMs || 0;
  const isGenerating = useChatStore(s => s.activeMessage !== null);
  
  // Calculate simulated metrics for visual effect since we don't have the real Rust engine backend metrics
  // TTFT Target
  const ttftRatio = isGenerating ? Math.min(ttftMs / 300, 1) : 0;
  
  // Sparsity (Sub-1-Bit engine simulated metric)
  const sparsity = isGenerating ? 0.65 + (Math.sin(Date.now() / 1000) * 0.1) : 0.05;
  
  // KV Pages Used (grows while generating)
  const [kvPages, setKvPages] = useState(0);
  useEffect(() => {
    if (isGenerating) {
      const interval = setInterval(() => {
        setKvPages(prev => Math.min(prev + 1, 1024));
      }, 100);
      return () => clearInterval(interval);
    } else {
      setKvPages(0);
    }
  }, [isGenerating]);

  // Get Theme Colors
  const accent = getComputedStyle(document.documentElement).getPropertyValue('--forge-accent').trim() || '#00E5FF';
  const warning = getComputedStyle(document.documentElement).getPropertyValue('--forge-warning').trim() || '#FFD600';
  const danger = getComputedStyle(document.documentElement).getPropertyValue('--forge-danger').trim() || '#FF2D95';
  
  const sparsityColor = sparsity < 0.3 ? accent : sparsity < 0.7 ? '#FF2ACC' : danger;

  return (
    <div className="absolute top-12 right-6 z-40 w-[240px] skeuo-panel p-4 flex flex-col gap-4 text-forge-text font-sans select-none pointer-events-none opacity-80 backdrop-blur-xl">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-2 h-2 rounded-full bg-forge-accent animate-pulse shadow-[0_0_8px_var(--forge-accent)]" />
        <span className="text-[10px] tracking-widest font-bold uppercase text-forge-accent">Telemetry HUD</span>
      </div>

      <div className="flex justify-between gap-2">
        <RadialGauge 
          value={vramUsedMb} 
          max={8192} 
          label="VRAM" 
          subLabel={`${(vramUsedMb / 1024).toFixed(1)} / 8 GB`} 
          colorHex={accent} 
        />
        <RadialGauge 
          value={ramUsedMb} 
          max={16384} 
          label="RAM" 
          subLabel={`${(ramUsedMb / 1024).toFixed(1)} / 16 GB`} 
          colorHex={warning} 
        />
      </div>

      <ScrollGraph 
        value={tps} 
        label="Token Speed" 
        unit="Tok/s" 
        colorHex="#B6FF3D" 
      />

      <MetricBar 
        label="TTFT" 
        valueStr={`${Math.round(ttftMs)} ms`} 
        progress={ttftRatio} 
        colorHex={accent} 
      />

      <MetricBar 
        label="Sparsity" 
        valueStr={sparsity.toFixed(2)} 
        progress={sparsity} 
        colorHex={sparsityColor} 
      />

      <CellGrid 
        used={kvPages} 
        total={1024} 
        label="KV Pages" 
        colorHex={sparsityColor} 
      />
    </div>
  );
}
