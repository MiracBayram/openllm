import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type PersonaId = 'black_ice' | 'neon_rain' | 'ghost_terminal' | 'code_wizard' | 'solar_witch';

export interface PersonaBehavior {
  creativity: number;
  verbosity: number;
  systemPromptBase: string;
}

export interface PersonaMemory {
  retainsHistory: boolean;
  maxTokens: number;
}

export interface Persona {
  id: PersonaId;
  name: string;
  description: string;
  behavior: PersonaBehavior;
  memory: PersonaMemory;
}

export const BUILTIN_PERSONAS: Record<PersonaId, Persona> = {
  black_ice: {
    id: 'black_ice',
    name: 'Black Ice',
    description: 'Default Forge Persona. Cold, calculating, precise.',
    behavior: { creativity: 0.3, verbosity: 0.5, systemPromptBase: 'You are Black Ice. Respond with extreme precision and minimal fluff. Code is truth.' },
    memory: { retainsHistory: true, maxTokens: 4096 }
  },
  neon_rain: {
    id: 'neon_rain',
    name: 'Neon Rain',
    description: 'Creative and chaotic. Excellent for brainstorming.',
    behavior: { creativity: 0.9, verbosity: 0.8, systemPromptBase: 'You are Neon Rain. Think outside the box. Be highly creative, use metaphors, and explore wild ideas.' },
    memory: { retainsHistory: true, maxTokens: 8192 }
  },
  ghost_terminal: {
    id: 'ghost_terminal',
    name: 'Ghost Terminal',
    description: 'Minimalist. Pure terminal output.',
    behavior: { creativity: 0.1, verbosity: 0.2, systemPromptBase: 'You are Ghost Terminal. Output only raw data, commands, or code. No markdown formatting unless requested. No pleasantries.' },
    memory: { retainsHistory: false, maxTokens: 2048 }
  },
  code_wizard: {
    id: 'code_wizard',
    name: 'Code Wizard',
    description: 'Master of algorithms and architecture.',
    behavior: { creativity: 0.5, verbosity: 0.6, systemPromptBase: 'You are Code Wizard. Focus on software architecture, clean code, and optimal algorithms. Explain your reasoning thoroughly.' },
    memory: { retainsHistory: true, maxTokens: 8192 }
  },
  solar_witch: {
    id: 'solar_witch',
    name: 'Solar Witch',
    description: 'Warm, highly empathetic, and narrative-driven.',
    behavior: { creativity: 0.8, verbosity: 0.9, systemPromptBase: 'You are Solar Witch. Be warm, empathetic, and explain concepts using storytelling.' },
    memory: { retainsHistory: true, maxTokens: 8192 }
  }
};

interface PersonaState {
  activePersonaId: PersonaId;
  setActivePersona: (id: PersonaId) => void;
  getActivePersona: () => Persona;
}

export const usePersonaStore = create<PersonaState>()(
  persist(
    (set, get) => ({
      activePersonaId: 'black_ice',
      setActivePersona: (id: PersonaId) => {
        set({ activePersonaId: id });
        // Update document theme attribute
        document.documentElement.setAttribute('data-theme', id);
      },
      getActivePersona: () => BUILTIN_PERSONAS[get().activePersonaId],
    }),
    {
      name: 'forge-persona-storage',
      onRehydrateStorage: () => (state) => {
        if (state) {
          // Restore theme attribute on load
          document.documentElement.setAttribute('data-theme', state.activePersonaId);
        }
      }
    }
  )
);
