import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import {  Server, Play, Square, Activity, AlertTriangle  } from 'lucide';
import { Icon } from './ui/Icon';
import { useConfigStore } from '../store/configStore';

export function ServerView() {
  const { config } = useConfigStore();
  const [running, setRunning] = useState(false);
  const [port, setPort] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Component mount olduğunda backend'den durumu sorgula (mock veya gerçek)
    // Eğer get_server_status yoksa fail olur ama devam eder
    invoke<{running: boolean, port: number}>('get_server_status')
      .then(res => {
        setRunning(res.running);
        if (res.port) setPort(res.port);
      })
      .catch(() => {
        // Rust'ta henüz yoksa yoksay
      });
  }, []);

  const toggleServer = async () => {
    setError('');
    try {
      if (running) {
        await invoke('stop_local_server');
        setRunning(false);
        setPort(null);
      } else {
        const p = await invoke<number>('start_local_server', { apiKey: config?.network?.api_key_uuid || 'sk-forge-local' });
        setPort(p);
        setRunning(true);
      }
    } catch (err: any) {
      setError(err.toString());
    }
  };

  return (
    <div className="flex-1 flex flex-col p-8 bg-forge-bg text-forge-text overflow-y-auto">
      <div className="max-w-4xl w-full mx-auto flex flex-col gap-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold mb-2">Server Dashboard</h1>
            <p className="text-forge-text/70">Manage the local OpenAI-compatible REST API.</p>
          </div>
          <button 
            onClick={toggleServer}
            className={`px-6 py-2.5 rounded-lg font-medium flex items-center justify-center gap-2 transition-all skeuo-btn ${
              running 
                ? 'bg-forge-danger/10 text-rose-400 border border-rose-500/30 hover:bg-forge-danger/20' 
                : 'bg-forge-accent text-forge-text hover:bg-forge-accent'
            }`}
          >
            {running ? <><Icon icon={Square} size={16} fill="currentColor" /> Stop Server</> : <><Icon icon={Play} size={16} fill="currentColor" /> Start Server</>}
          </button>
        </div>

        {error && (
          <div className="bg-forge-danger/10 text-rose-400 border border-rose-500/20 p-4 rounded-lg text-sm flex items-center gap-2">
            <Icon icon={AlertTriangle} size={16} />
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="skeuo-panel p-6 flex flex-col gap-4 col-span-1">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-forge-text-muted">Status</h3>
            <div className="flex items-center gap-3">
              <div className="bg-forge-surface p-3 rounded-full border border-forge-border">
                <Icon icon={Server} size={24} className={running ? "text-emerald-400" : "text-forge-text-muted"} />
              </div>
              <div className="flex flex-col">
                <span className={`font-semibold ${running ? "text-emerald-400" : "text-forge-text-muted"}`}>
                  {running ? "Online" : "Offline"}
                </span>
                <span className="text-xs text-forge-text-muted">
                  {running ? `Port ${port}` : "Not listening"}
                </span>
              </div>
            </div>
            {running && port && (
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(`http://localhost:${port}`);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="mt-4 flex items-center justify-center gap-2 text-xs py-2 bg-forge-surface-2 hover:bg-forge-surface-3 rounded border border-forge-border transition-colors text-forge-text"
              >
                {copied ? "Copied!" : `Copy http://localhost:${port}`}
              </button>
            )}
          </div>

          <div className="skeuo-panel p-6 flex flex-col gap-4 col-span-2">
            <h3 className="text-sm font-semibold uppercase tracking-widest text-forge-text-muted flex items-center gap-2">
              <Icon icon={Activity} size={14} /> Active Endpoints
            </h3>
            {running ? (
              <div className="flex flex-col gap-3 font-mono text-xs">
                <div className="flex items-center justify-between bg-forge-surface border border-forge-border p-3 rounded-md">
                  <span className="text-forge-accent">GET /v1/models</span>
                  <span className="text-forge-text-muted">List available models</span>
                </div>
                <div className="flex items-center justify-between bg-forge-surface border border-forge-border p-3 rounded-md">
                  <span className="text-forge-accent">POST /v1/chat/completions</span>
                  <span className="text-forge-text-muted">Generate chat response</span>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-forge-text-muted text-sm">
                Start the server to see endpoints.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
