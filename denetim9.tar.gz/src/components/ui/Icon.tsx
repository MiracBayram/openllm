import { createElement } from 'react';

interface IconProps {
  icon: any; // Using any because IconNode typedef in vanilla is strict
  size?: number;
  className?: string;
  strokeWidth?: number;
  fill?: string;
}

export function Icon({ icon, size = 24, className, strokeWidth = 2, fill = "none" }: IconProps) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill={fill}
      stroke="currentColor" 
      strokeWidth={strokeWidth} 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <>{(icon as any[]).map(([tag, attrs], i) => createElement(tag, { ...attrs, key: i }))}</>
    </svg>
  );
}
