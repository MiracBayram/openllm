import {  MessageSquare, Server, Download, Settings, PanelRightOpen  } from 'lucide';
import { Icon } from './ui/Icon';
import { useUiStore } from '../store/uiStore';

export function Sidebar() {
  const { activeTab, setActiveTab, toggleInspector, inspectorOpen } = useUiStore();

  const tabs = [
    { id: 'chat', icon: MessageSquare, label: 'Chat' },
    { id: 'hub', icon: Download, label: 'Hub' },
    { id: 'server', icon: Server, label: 'Server' },
    { id: 'settings', icon: Settings, label: 'Settings' }
  ] as const;

  return (
    <div className="w-16 bg-forge-bg border-r border-forge-border flex flex-col py-6 px-2 gap-4 z-40 shrink-0">
      <div className="flex flex-col gap-2 flex-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center justify-center p-3 rounded-lg transition-all duration-200 group relative w-full ${
              activeTab === tab.id 
                ? 'text-forge-accent bg-forge-surface/40' 
                : 'text-forge-text-muted hover:text-forge-text hover:bg-forge-surface/30'
            }`}
            title={tab.label}
          >
            {activeTab === tab.id && (
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-1/2 bg-forge-accent rounded-r-full shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
            )}
            <Icon icon={tab.icon} size={22} strokeWidth={activeTab === tab.id ? 2.5 : 2} className="shrink-0" />
          </button>
        ))}
      </div>

      {activeTab === 'chat' && !inspectorOpen && (
        <button 
          onClick={toggleInspector}
          className="flex items-center justify-center p-3 rounded-lg text-forge-text-muted hover:text-forge-text hover:bg-forge-surface/30 transition-all group"
          title="Open Inspector"
        >
          <Icon icon={PanelRightOpen} size={20} strokeWidth={2} />
        </button>
      )}
    </div>
  );
}
