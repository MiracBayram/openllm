import { useHardwareLerp } from '../hooks/useHardwareLerp';
import { useTelemetryHUD } from '../store/telemetryStore';
import {  Cpu, Activity  } from 'lucide';
import { Icon } from './ui/Icon';
import { useEffect, useRef } from 'react';
import { TelemetryRingBuffer } from '../utils/TelemetryRingBuffer';

export function HardwareHUD() {
  const { vramUsedMb, oomRisk } = useHardwareLerp();
  const { tps } = useTelemetryHUD();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const ringBuffer = useRef(new TelemetryRingBuffer(60)); // 60 data points
  const isVisible = useRef(true);

  const vramRef = useRef(vramUsedMb);
  useEffect(() => {
    vramRef.current = vramUsedMb;
  }, [vramUsedMb]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const dpr = window.devicePixelRatio || 1;
    if (canvas) {
      canvas.width = 80 * dpr;
      canvas.height = 24 * dpr;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.scale(dpr, dpr);
    }

    let animationFrameId: number | undefined;

    const drawFrame = () => {
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, 80, 24);
          
          if (ringBuffer.current.count > 1) {
            ctx.beginPath();
            const stepX = 80 / (60 - 1);
            
            // Auto scale Y axis based on max vram in buffer
            let maxVal = 1024;
            for (const val of ringBuffer.current.iterateFromHead()) {
              if (val > maxVal) maxVal = val;
            }
            
            let i = 0;
            for (const val of ringBuffer.current.iterateFromHead()) {
              const x = i * stepX;
              const normalizedY = 1.0 - (val / maxVal);
              const y = normalizedY * 24;
              
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
              
              i++;
            }
            
            ctx.strokeStyle = '#6366f1'; // Indigo 500
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // Fill area under curve
            ctx.lineTo((ringBuffer.current.count - 1) * stepX, 24);
            ctx.lineTo(0, 24);
            ctx.closePath();

            const gradient = ctx.createLinearGradient(0, 0, 0, 24);
            gradient.addColorStop(0, 'rgba(99, 102, 241, 0.4)');
            gradient.addColorStop(1, 'rgba(99, 102, 241, 0)');
            ctx.fillStyle = gradient;
            ctx.fill();
          }
        }
      }
    };

    const animate = () => {
      if (!isVisible.current) {
        animationFrameId = undefined;
        return;
      }
      drawFrame();
      animationFrameId = requestAnimationFrame(animate);
    };

    const startAnimation = () => {
      if (!animationFrameId) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    const dataInterval = setInterval(() => {
      ringBuffer.current.push(vramRef.current);
    }, 100);

    let observer: IntersectionObserver | null = null;
    if (containerRef.current) {
      observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          isVisible.current = entry.isIntersecting;
          if (entry.isIntersecting) {
            startAnimation();
          } else if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = undefined;
          }
        });
      }, { threshold: 0.1 });
      observer.observe(containerRef.current);
    }

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      clearInterval(dataInterval);
      if (observer) observer.disconnect();
    };
  }, []);

  return (
    <div ref={containerRef} className="flex items-center gap-6 px-6 py-3 border-b border-forge-border bg-forge-bg/50 shrink-0">
      <div className="flex items-center gap-2 text-forge-text/70">
        <Icon icon={Activity} size={16} className="text-forge-accent" />
        <span className="text-xs font-semibold uppercase tracking-widest">Telemetry</span>
      </div>

      <div className="h-4 w-px bg-forge-surface" />

      <div className="flex items-center gap-3">
        <Icon icon={Cpu} size={14} className="text-forge-text-muted" />
        <div className="flex flex-col">
          <span className="text-[10px] text-forge-text-muted font-semibold uppercase tracking-wider">VRAM</span>
          <span className={`text-sm font-mono ${oomRisk === 'Critical' ? 'text-forge-danger' : 'text-forge-text'}`}>
            {vramUsedMb} MB
          </span>
        </div>
        
        {/* Hardware HUD Canvas */}
        <div className="ml-2 w-20 h-6">
          <canvas 
            ref={canvasRef} 
            className="w-full h-full block drop-shadow-[0_0_3px_rgba(99,102,241,0.5)]" 
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-forge-accent/10 flex items-center justify-center border border-forge-accent/20">
          <Icon icon={Activity} size={16} className="text-forge-accent" />
        </div>
        <div className="flex flex-col">
          <span className="text-[10px] text-forge-text-muted font-semibold uppercase tracking-wider">TPS</span>
          <span className="text-sm font-mono text-forge-accent font-medium">
            {tps.toFixed(1)} <span className="text-xs text-forge-accent/50">t/s</span>
          </span>
        </div>
      </div>

      <div className="h-4 w-px bg-forge-surface" />

      <div className="flex items-center">
        <span className={`text-[10px] px-2 py-0.5 rounded border font-semibold uppercase ${
          oomRisk === 'Safe' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/10' :
          oomRisk === 'Marginal' ? 'text-orange-400 border-orange-500/20 bg-orange-500/10' :
          'text-forge-danger border-rose-500/20 bg-forge-danger/10 animate-pulse'
        }`}>
          {oomRisk}
        </span>
      </div>
    </div>
  );
}
