import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import {  CheckCircle2, ChevronRight, Zap  } from 'lucide';
import { Icon } from './ui/Icon';
import { useUiStore } from '../store/uiStore';

export function OnboardingWizard() {
  const [step, setStep] = useState(0);
  const [hardware, setHardware] = useState<any>(null);
  const [selectedEngines, setSelectedEngines] = useState<string[]>(['llama.cpp', 'lmdeploy']);
  const [isInitializing, setIsInitializing] = useState(false);
  const { setOnboardingComplete } = useUiStore();

  useEffect(() => {
    // Rust'tan donanım verisini çek
    invoke('get_hardware_profile').then((res: any) => {
      setHardware(res);
      // Auto-select defaults based on hardware
      const isNvidia = res?.gpus?.some((g: any) => g.vendor === 'Nvidia');
      if (!isNvidia) {
        setSelectedEngines(['llama.cpp']); // Mac/AMD fallback
      }
    }).catch(err => {
      console.error(err);
      setHardware({ fallback: true, name: "Unknown GPU (Fallback Mode)" });
    });
  }, []);

  const toggleEngine = (engine: string) => {
    if (selectedEngines.includes(engine)) {
      setSelectedEngines(selectedEngines.filter(e => e !== engine));
    } else {
      setSelectedEngines([...selectedEngines, engine]);
    }
  };

  const finish = async () => {
    setIsInitializing(true);
    try {
      await invoke('initialize_engines', { engines: selectedEngines });
    } catch (e) {
      console.warn("Backend invoke failed, but continuing for UI:", e);
    }
    setIsInitializing(false);
    setOnboardingComplete(true);
  };

  if (step === 0) {
    return (
      <div className="absolute inset-0 z-50 bg-forge-bg flex flex-col items-center justify-center p-8 text-forge-text">
        <div className="max-w-xl w-full flex flex-col gap-8 text-center animate-in fade-in zoom-in duration-500">
          <div className="w-20 h-20 bg-forge-accent/10 rounded-full flex items-center justify-center mx-auto border border-forge-accent/20">
            <Icon icon={Zap} className="text-forge-accent" size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-semibold mb-4 tracking-tight">Welcome to Forge</h1>
            <p className="text-forge-text/70 text-lg">
              The ultimate local AI operating system. Let's configure your engines.
            </p>
          </div>
          <div className="flex gap-2 justify-center mb-4">
            <div className="w-2 h-2 rounded-full bg-forge-accent"></div>
            <div className="w-2 h-2 rounded-full bg-forge-surface"></div>
          </div>
          <button 
            onClick={() => setStep(1)}
            className="bg-forge-accent hover:bg-forge-accent text-forge-text py-4 px-8 rounded-lg font-semibold text-lg transition-all mx-auto shadow-[0_0_20px_rgba(99,102,241,0.3)] hover:shadow-[0_0_30px_rgba(99,102,241,0.5)] flex items-center gap-2 hover:scale-105"
          >
            Get Started <Icon icon={ChevronRight} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-50 bg-forge-bg flex flex-col items-center justify-center p-8 text-forge-text">
      <div className="max-w-2xl w-full flex flex-col gap-6 animate-in slide-in-from-bottom-10 fade-in duration-500">
        <div className="flex justify-between items-center w-full">
          <h2 className="text-2xl font-semibold">Hardware Profile</h2>
          <div className="flex gap-2">
            <div className="w-2 h-2 rounded-full bg-forge-surface"></div>
            <div className="w-2 h-2 rounded-full bg-forge-accent"></div>
          </div>
        </div>
        
        <div className="bg-forge-surface border border-forge-border rounded-xl p-6 flex items-center gap-4">
          {hardware ? (
            <>
              <Icon icon={CheckCircle2} className="text-emerald-400" />
              <div className="flex flex-col">
                <span className="font-mono text-forge-text">
                  {hardware.gpus ? hardware.gpus[0].name : hardware.name}
                </span>
                <span className="text-xs text-forge-text-muted">
                  {hardware.gpus ? `${hardware.gpus[0].vram_mb} MB VRAM` : 'Hardware detection active'}
                </span>
              </div>
            </>
          ) : (
            <>
              <div className="animate-spin w-5 h-5 border-2 border-forge-accent border-t-transparent rounded-full" />
              <span className="text-forge-text/70">Scanning OS registry via Rust tokio blocking task...</span>
            </>
          )}
        </div>

        <h2 className="text-2xl font-semibold mt-4">Required Engines</h2>
        <div className="grid grid-cols-2 gap-4">
          {/* Llama.cpp (Universal) */}
          <div 
            onClick={() => toggleEngine('llama.cpp')}
            className={`bg-forge-surface border-2 ${selectedEngines.includes('llama.cpp') ? 'border-forge-accent' : 'border-forge-border'} rounded-xl p-6 cursor-pointer relative overflow-hidden transition-colors`}
          >
            <h3 className="font-semibold text-lg text-forge-text mb-2">Llama.cpp</h3>
            <p className="text-sm text-forge-text/70">Fallback CPU/GPU hybrid engine. Wide GGUF support.</p>
          </div>

          {/* LMDeploy (Nvidia/AMD) */}
          <div 
            onClick={() => toggleEngine('lmdeploy')}
            className={`bg-forge-surface border-2 ${selectedEngines.includes('lmdeploy') ? 'border-forge-accent' : 'border-forge-border'} rounded-xl p-6 cursor-pointer relative overflow-hidden transition-colors`}
          >
            <h3 className="font-semibold text-lg text-forge-text mb-2">LMDeploy</h3>
            <p className="text-sm text-forge-text/70">Optimized for AWQ/W4A16. Extremely fast.</p>
          </div>

          {/* vLLM */}
          <div 
            onClick={() => toggleEngine('vllm')}
            className={`bg-forge-surface border-2 ${selectedEngines.includes('vllm') ? 'border-forge-accent' : 'border-forge-border'} rounded-xl p-6 cursor-pointer relative overflow-hidden transition-colors`}
          >
            <h3 className="font-semibold text-lg text-forge-text mb-2">vLLM</h3>
            <p className="text-sm text-forge-text/70">High-throughput serving engine.</p>
          </div>

          {/* TensorRT-LLM (Hardware Gated) */}
          <div 
            className="bg-forge-surface/50 border-2 border-forge-border/50 rounded-xl p-6 relative overflow-hidden opacity-50 cursor-not-allowed group col-span-2 sm:col-span-1"
          >
            <h3 className="font-semibold text-lg text-forge-text-muted mb-2">TensorRT-LLM</h3>
            <p className="text-sm text-zinc-600">Max NVIDIA performance.</p>
            <div className="absolute inset-0 bg-forge-bg/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-xs font-mono text-amber-500 bg-amber-500/10 px-2 py-1 rounded">Requires NVIDIA CUDA 8.0+</span>
            </div>
          </div>

          {/* PowerInfer */}
          <div 
            onClick={() => toggleEngine('powerinfer')}
            className={`bg-forge-surface border-2 ${selectedEngines.includes('powerinfer') ? 'border-forge-accent' : 'border-forge-border'} rounded-xl p-6 cursor-pointer relative overflow-hidden transition-colors`}
          >
            <h3 className="font-semibold text-lg text-forge-text mb-2">PowerInfer</h3>
            <p className="text-sm text-forge-text/70">CPU/GPU sparsity offloading.</p>
          </div>
        </div>

        <button 
          onClick={finish}
          disabled={!hardware || selectedEngines.length === 0 || isInitializing}
          className="bg-forge-accent disabled:bg-forge-surface disabled:text-forge-text-muted hover:bg-forge-accent text-forge-text py-4 w-full rounded-lg font-semibold text-lg transition-all mt-4 shadow-[0_0_20px_rgba(99,102,241,0.2)] flex items-center justify-center gap-2"
        >
          {isInitializing ? (
            <><div className="animate-spin w-5 h-5 border-2 border-forge-text border-t-transparent rounded-full" /> Initializing...</>
          ) : (
            `Initialize Selected Engines (${selectedEngines.length})`
          )}
        </button>
      </div>
    </div>
  );
}
