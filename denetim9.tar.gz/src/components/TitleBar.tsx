import {  Minus, Square, X, Hexagon  } from 'lucide';
import { Icon } from './ui/Icon';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { useConfigStore } from '../store/configStore';
import { platform } from '@tauri-apps/plugin-os';
import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';

let cachedOs: 'macos' | 'windows' | 'linux' | null = null;

export function TitleBar() {
  const { config } = useConfigStore();
  const [os, setOs] = useState<'macos' | 'windows' | 'linux'>('linux');

  useEffect(() => {
    if (!cachedOs) {
      cachedOs = platform() as any;
    }
    if (cachedOs) setOs(cachedOs);
  }, []);

  const handleMinimize = () => invoke('window_minimize');
  const handleMaximize = () => invoke('window_maximize');
  const handleClose = async () => {
    try {
      await invoke('window_close');
    } catch (e) {
      console.error(e);
      await invoke('stop_inference');
      setTimeout(() => window.close(), 500);
    }
  };

  const handleDrag = (e: React.PointerEvent) => {
    if (e.buttons === 1) {
      invoke('window_start_dragging');
    }
  };

  return (
    <div 
      className="h-10 bg-forge-bg border-b border-forge-border flex items-center justify-between shrink-0 select-none"
      onPointerDown={handleDrag}
    >
      {/* Mac Traffic Lights */}
      {os === 'macos' && (
        <div className="flex items-center gap-2 px-4 h-full pointer-events-auto z-50">
          <button onClick={handleClose} className="w-3 h-3 rounded-full bg-[#FF5F56] border border-[#E0443E] hover:brightness-110 active:brightness-90 transition-all group flex items-center justify-center">
            <Icon icon={X} size={8} className="opacity-0 group-hover:opacity-100 text-black/60" />
          </button>
          <button onClick={handleMinimize} className="w-3 h-3 rounded-full bg-[#FFBD2E] border border-[#DEA123] hover:brightness-110 active:brightness-90 transition-all group flex items-center justify-center">
            <Icon icon={Minus} size={8} className="opacity-0 group-hover:opacity-100 text-black/60" />
          </button>
          <button onClick={handleMaximize} className="w-3 h-3 rounded-full bg-[#27C93F] border border-[#1AAB29] hover:brightness-110 active:brightness-90 transition-all group flex items-center justify-center">
            <Icon icon={Square} size={8} className="opacity-0 group-hover:opacity-100 text-black/60" />
          </button>
        </div>
      )}

      {/* Brand & Theme */}
      <div className={`flex items-center gap-2 h-full pointer-events-none z-50 ${os === 'macos' ? 'absolute left-1/2 -translate-x-1/2' : 'px-4'}`}>
        <Icon icon={Hexagon} size={16} className="text-forge-accent" />
        <span className="font-semibold text-xs tracking-wider text-forge-text">FORGE</span>
        {config?.ui?.theme && (
          <span className="text-[10px] text-zinc-600 font-mono ml-2 border border-forge-border px-1.5 rounded bg-forge-text/5">
            {config.ui.theme.toUpperCase()}
          </span>
        )}
      </div>

      {/* Windows/Linux Controls */}
      {os !== 'macos' && (
        <div className="flex h-full pointer-events-auto z-50 ml-auto">
          <button 
            onClick={handleMinimize}
            className="w-12 h-full flex items-center justify-center text-forge-text/70 hover:bg-forge-text/5 hover:text-forge-text transition-colors relative"
          >
            <Icon icon={Minus} size={16} />
          </button>
          <button 
            onClick={handleMaximize}
            className="w-12 h-full flex items-center justify-center text-forge-text/70 hover:bg-forge-text/5 hover:text-forge-text transition-colors relative"
          >
            <Icon icon={Square} size={14} />
          </button>
          <button 
            onClick={handleClose}
            className="w-12 h-full flex items-center justify-center text-forge-text/70 hover:bg-forge-danger hover:text-forge-text transition-colors relative"
          >
            <Icon icon={X} size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
