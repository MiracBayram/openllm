import { useState, useEffect, useRef, useMemo } from 'react';
import { useChatStore } from '../store/chatStore';
import { useInferenceStore } from '../store/inference';
import { useStreamBypass } from '../hooks/useStreamBypass';
import { Virtuoso } from 'react-virtuoso';
import { invoke } from '@tauri-apps/api/core';
import { useTauriEvent } from '../hooks/useTauriEvent';
import { SendHorizontal, Square, AlertTriangle, Trash2 } from 'lucide';
import { Icon } from './ui/Icon';
import { CodeBlock } from './CodeBlock';
import React, { Suspense } from 'react';

const ReactMarkdown = React.lazy(() => import('react-markdown'));
const SuspenseAny = Suspense as any;

export function ChatView() {
  const { messages, activeMessage, addMessage, setActiveMessage, appendContentToActiveMessage, commitActiveMessage, clearMessages } = useChatStore();
  const { config } = useInferenceStore();
  const [input, setInput] = useState('');
  const [activeStreamId, setActiveStreamId] = useState<string | null>(null);
  
  const { domNodeRef: streamNodeRef, getFinalContent } = useStreamBypass(activeStreamId);
  const virtuosoRef = useRef<any>(null);

  const allMessages = useMemo(() => activeMessage ? [...messages, activeMessage] : messages, [messages, activeMessage]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (virtuosoRef.current) {
      virtuosoRef.current.scrollToIndex({ index: allMessages.length, align: 'end', behavior: 'smooth' });
    }
  }, [allMessages.length]);

  useTauriEvent<any>('forge://done', (_payload) => {
    if (activeStreamId && streamNodeRef.current) {
      // Stream finished, get exact buffer from hook
      const finalContent = getFinalContent();
      appendContentToActiveMessage(finalContent);
      commitActiveMessage();
      streamNodeRef.current.textContent = ''; // clear DOM node
      setActiveStreamId(null);
    }
  });

  useTauriEvent<string>('forge://error', (errorMsg) => {
    addMessage({
      id: crypto.randomUUID(),
      role: 'error',
      content: errorMsg
    });
    setActiveStreamId(null);
  });

  const handleSend = async () => {
    if (!input.trim() || activeStreamId) return;
    
    if (!config.modelPath) {
      alert("Lütfen önce sağ menüden bir model seçin.");
      return;
    }

    const userMsg = { id: crypto.randomUUID(), role: 'user' as const, content: input };
    addMessage(userMsg);
    setInput('');

    const assistantMsgId = crypto.randomUUID();
    const assistantMsg = { id: assistantMsgId, role: 'assistant' as const, content: '' };
    setActiveMessage(assistantMsg);
    
    setActiveStreamId(assistantMsgId);

    try {
      await invoke('start_inference', {
        modelPath: config.modelPath,
        params: { 
          max_tokens: config.max_tokens, 
          temperature: config.temperature, 
          prompt: input, 
          system_prompt: config.system_prompt,
          top_p: config.top_p,
          top_k: config.top_k,
          repeat_penalty: config.repeat_penalty,
          messages: allMessages.map(m => ({ role: m.role, content: m.content }))
        }
      });
    } catch (e) {
      console.error(e);
      setActiveStreamId(null);
    }
  };

  const handleStop = async () => {
    await invoke('stop_inference');
    setActiveStreamId(null);
  };

  const renderMessage = (index: number) => {
    const msg = allMessages[index];
    const isAssistant = msg.role === 'assistant';
    const isStreaming = activeStreamId === msg.id;

    return (
      <div className={`flex w-full mb-4 ${isAssistant ? 'justify-start' : msg.role === 'error' ? 'justify-center' : 'justify-end'}`}>
        {msg.role === 'error' ? (
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm max-w-2xl flex items-start gap-2 shadow-sm">
            <Icon icon={AlertTriangle} size={16} className="shrink-0 mt-0.5" />
            <span>{msg.content}</span>
          </div>
        ) : (
          <div className={`p-4 max-w-[85%] sm:max-w-2xl ${
            msg.role === 'user' 
              ? 'bg-forge-surface/60 border border-forge-border rounded-2xl rounded-tr-sm text-forge-text shadow-sm' 
              : 'bg-transparent text-forge-text'
          }`}>
            {isStreaming ? (
              <span className="font-mono whitespace-pre-wrap">
                <span ref={streamNodeRef}></span>
                <span className="animate-pulse">|</span>
              </span>
            ) : msg.role === 'user' ? (
            <p className="whitespace-pre-wrap">{msg.content}</p>
          ) : (
            <>
              {/* @ts-ignore */}
              <SuspenseAny fallback={<span className="animate-pulse">Rendering...</span>}>
              <div className="prose prose-invert prose-p:leading-relaxed prose-pre:p-0 prose-pre:bg-transparent">
                {/* @ts-ignore */}
                <ReactMarkdown
                  components={{
                    // @ts-ignore
                    code({node, inline, className, children, ...props}: any) {
                      const match = /language-(\w+)/.exec(className || '');
                      return !inline && match ? (
                        <CodeBlock code={String(children).replace(/\n$/, '')} lang={match[1]} />
                      ) : (
                        <code {...props} className="bg-forge-surface border border-forge-border px-1.5 py-0.5 rounded text-indigo-300 font-mono text-sm">
                          {children}
                        </code>
                      );
                    }
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
              </div>
              </SuspenseAny>
            </>
          )}
        </div>
        )}
      </div>
    );
  };



  return (
    <div className="flex flex-col flex-1 h-full bg-forge-bg relative">
      <div className="flex-1 p-4 overflow-hidden flex flex-col">
        {allMessages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center select-none">
            <h1 className="text-4xl font-bold text-forge-text mb-2">Forge</h1>
            <p className="text-forge-text-secondary mb-8">Nasıl yardımcı olabilirim?</p>
            
            <div className="grid grid-cols-2 gap-4 max-w-2xl w-full px-4">
              {[
                { icon: '💻', text: 'Kod yazmama yardım et', prompt: 'Bana Python ile bir web scraper yaz' },
                { icon: '📝', text: 'Metin özetle', prompt: 'Aşağıdaki metni özetle:\n\n' },
                { icon: '📊', text: 'Veri analizi yap', prompt: 'Bu CSV dosyasını analiz et:\n\n' },
                { icon: '🔍', text: 'Araştırma yap', prompt: 'Şu konu hakkında araştırma yap: ' },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => setInput(item.prompt)}
                  className="p-4 bg-forge-surface hover:bg-forge-surface-3 border border-forge-border rounded-xl transition-colors text-left flex flex-col gap-2 group"
                >
                  <div className="text-2xl group-hover:scale-110 transition-transform">{item.icon}</div>
                  <div className="text-forge-text font-medium">{item.text}</div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            <Virtuoso
              ref={virtuosoRef}
              data={allMessages}
              itemContent={renderMessage as any}
              followOutput="smooth"
              className="h-full w-full custom-scrollbar"
            />
            <button
              onClick={clearMessages}
              className="absolute top-4 right-4 z-10 p-2 rounded-lg bg-forge-surface/80 border border-forge-border text-forge-text-muted hover:text-red-400 hover:border-red-400/30 transition-all shadow-sm"
              title="Sohbeti Temizle"
            >
              <Icon icon={Trash2} size={16} />
            </button>
          </>
        )}
      </div>

      <div className="p-4 border-t border-forge-border bg-forge-bg">
        <div className="flex items-end gap-2 max-w-3xl mx-auto relative bg-forge-surface/30 border border-forge-border rounded-xl p-2 shadow-sm focus-within:border-forge-accent/50 transition-colors">
          <textarea
            value={input}
            onChange={(e: any) => {
              setInput(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.ctrlKey || e.metaKey || !e.shiftKey)) {
                e.preventDefault();
                handleSend();
              }
            }}
            disabled={!!activeStreamId}
            placeholder="Mesajınızı yazın..."
            rows={1}
            className="w-full bg-transparent resize-none px-3 py-2 text-forge-text focus:outline-none disabled:opacity-50 custom-scrollbar max-h-48"
          />
          {activeStreamId ? (
            <button 
              onClick={handleStop}
              className="p-2.5 bg-forge-surface hover:bg-forge-danger/20 text-forge-danger rounded-lg transition-colors border border-transparent hover:border-forge-danger shrink-0 mb-1 flex items-center justify-center"
            >
              <Icon icon={Square} size={20} className="fill-current" />
            </button>
          ) : (
            <button 
              onClick={handleSend}
              disabled={!input.trim()}
              className="p-2.5 bg-forge-surface hover:bg-forge-accent hover:text-forge-text text-forge-text/50 rounded-lg transition-colors border border-forge-border hover:border-forge-accent shrink-0 mb-1 disabled:opacity-30 flex items-center justify-center"
            >
              <Icon icon={SendHorizontal} size={20} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
