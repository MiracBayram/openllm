import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import {  Search, Download, Star  } from 'lucide-react';
import { Icon } from './ui/Icon';
import { useMagnetic } from '../hooks/useMagnetic';
import { useModelsStore } from '../store/models';
import { useConfigStore } from '../store/configStore';

interface HubModel {
  model_id: string;
  downloads: number;
  likes: number;
  tags: string[];
}

interface DownloadState {
  progress: number;
  speed: string;
  status: string;
}

export function HubView() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<HubModel[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeDownloads, setActiveDownloads] = useState<Record<string, DownloadState>>({});
  const [expandedModel, setExpandedModel] = useState<string | null>(null);
  const [modelFiles, setModelFiles] = useState<any[]>([]);
  const [filesLoading, setFilesLoading] = useState(false);

  useEffect(() => {
    const unlisten = listen('forge://download::progress', (event: any) => {
      const payload = event.payload;
      const percent = payload.total_bytes > 0 
        ? Math.round((payload.downloaded_bytes / payload.total_bytes) * 100) 
        : 0;
      
      let speedText = '';
      if (payload.speed_bps > 0) {
        speedText = `${(payload.speed_bps / 1024 / 1024).toFixed(1)} MB/s`;
      }

      let statusMsg = payload.status;
      if (typeof statusMsg === 'object' && statusMsg.Error) {
        statusMsg = 'Error: ' + statusMsg.Error;
      }

      if (statusMsg === 'Completed') {
        const appConfig = useConfigStore.getState().config;
        if (appConfig?.storage.models_directory) {
          useModelsStore.getState().scanModels(appConfig.storage.models_directory);
        }
      }

      setActiveDownloads(prev => ({
        ...prev,
        [payload.model_id]: {
          progress: percent,
          speed: speedText,
          status: statusMsg
        }
      }));
    });

    return () => {
      unlisten.then(f => f());
    };
  }, []);

  const fetchModelFiles = async (modelId: string) => {
    if (expandedModel === modelId) {
      setExpandedModel(null);
      return;
    }
    setExpandedModel(modelId);
    setFilesLoading(true);
    setModelFiles([]);
    try {
      const res = await fetch(`https://huggingface.co/api/models/${modelId}`);
      if (!res.ok) throw new Error(`HF API error`);
      const data = await res.json();
      
      // Filter for quantizations or weights
      const validFiles = data.siblings?.filter((s: any) => {
        const lower = s.rfilename.toLowerCase();
        return lower.endsWith('.gguf') || lower.endsWith('.awq') || lower.endsWith('.safetensors');
      }) || [];
      
      setModelFiles(validFiles);
    } catch (e) {
      console.error("Failed to fetch files", e);
    }
    setFilesLoading(false);
  };

  const handleDownload = async (modelId: string, file: any) => {
    try {
      setActiveDownloads(prev => ({ ...prev, [modelId]: { progress: 0, speed: 'Starting...', status: 'Initializing' } }));

      const fileName = file.rfilename;
      const expectedSha = file.lfs?.oid || "SKIP"; 
      await invoke('start_download', {
        modelId,
        fileName,
        expectedSha256: expectedSha
      });
    } catch (e: any) {
      setActiveDownloads(prev => ({ 
        ...prev, 
        [modelId]: { progress: 0, speed: '', status: `Error: ${e.message || e}` } 
      }));
    }
  };

  useEffect(() => {
    if (!query) {
      setResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await invoke<HubModel[]>('search_hub_models', { query });
        setResults(res);
      } catch (err) {
        console.error(err);
      }
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="flex-1 flex flex-col p-8 bg-forge-bg text-forge-text overflow-hidden">
      <div className="max-w-4xl w-full mx-auto flex flex-col gap-6 h-full">
        <div className="shrink-0">
          <h1 className="text-2xl font-semibold mb-2">Model Hub</h1>
          <p className="text-forge-text-muted">Search and select specific quantizations from Hugging Face.</p>
        </div>

        <form onSubmit={(e) => e.preventDefault()} className="flex gap-4 shrink-0">
          <div className="relative flex-1">
            <Icon icon={Search} className="absolute left-4 top-1/2 -translate-y-1/2 text-forge-text-muted" size={20} />
            <input 
              type="text" 
              value={query}
              onChange={(e) => setQuery((e.target as any).value)}
              placeholder="e.g., Llama-3-8B-Instruct-GGUF"
              className="w-full bg-forge-surface/50 border border-forge-border rounded-xl py-4 pl-12 pr-4 text-forge-text placeholder-zinc-600 outline-none focus:border-forge-accent transition-colors shadow-inner"
            />
          </div>
          <button 
            type="submit" 
            disabled={loading}
            className="bg-forge-accent hover:bg-forge-accent-hover text-forge-bg px-8 rounded-xl font-bold transition-all disabled:opacity-50"
          >
            {loading ? '...' : 'Search'}
          </button>
        </form>

        <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-4 pr-2 pb-10">
          {results.map((model, i) => (
            <div key={i} className="flex flex-col bg-forge-surface border border-forge-border rounded-xl overflow-hidden transition-all duration-300">
              
              {/* Card Header (Clickable) */}
              <div 
                className="p-5 flex flex-col gap-3 cursor-pointer hover:bg-forge-surface-3 transition-colors"
                onClick={() => fetchModelFiles(model.model_id)}
              >
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-bold text-forge-text">{model.model_id}</h3>
                  <div className="flex items-center gap-3 text-xs text-forge-text-muted font-medium bg-forge-bg px-3 py-1.5 rounded-lg border border-forge-border">
                    <span className="flex items-center gap-1.5"><Icon icon={Download} size={14} className="text-emerald-400" /> {model.downloads.toLocaleString()}</span>
                    <span className="flex items-center gap-1.5"><Icon icon={Star} size={14} className="text-amber-400" /> {model.likes.toLocaleString()}</span>
                  </div>
                </div>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2 overflow-hidden h-6">
                  {model.tags.slice(0, 6).map(t => (
                    <span key={t} className="bg-forge-surface-2 border border-forge-border-subtle px-2 py-0.5 rounded text-[10px] text-forge-text-secondary whitespace-nowrap">
                      {t}
                    </span>
                  ))}
                  {model.tags.length > 6 && <span className="text-[10px] text-forge-text-muted">+{model.tags.length - 6} more</span>}
                </div>

                {/* Active Download Progress (if any) */}
                {activeDownloads[model.model_id] && (
                  <div className="mt-2 p-3 bg-forge-bg rounded-lg border border-forge-border flex flex-col gap-1 w-full text-xs">
                    <div className="flex justify-between text-forge-text-secondary mb-1 font-mono">
                      <span>{activeDownloads[model.model_id].status}</span>
                      <span className="text-forge-accent">{activeDownloads[model.model_id].progress}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-forge-surface rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-300 ${activeDownloads[model.model_id].status.includes('Error') ? 'bg-forge-danger' : 'bg-forge-accent'}`}
                        style={{ width: `${activeDownloads[model.model_id].progress}%` }}
                      />
                    </div>
                    {activeDownloads[model.model_id].speed && (
                      <span className="text-forge-text-muted text-[10px] mt-1">{activeDownloads[model.model_id].speed}</span>
                    )}
                  </div>
                )}
              </div>

              {/* Files Accordion (Quantizations) */}
              {expandedModel === model.model_id && (
                <div className="bg-forge-bg border-t border-forge-border p-4">
                  <h4 className="text-xs font-semibold text-forge-text-muted uppercase tracking-widest mb-3 flex items-center gap-2">
                    Available Files
                  </h4>
                  {filesLoading ? (
                    <div className="text-sm text-forge-text-muted animate-pulse p-4 text-center">Scanning repository for weights...</div>
                  ) : modelFiles.length === 0 ? (
                    <div className="text-sm text-forge-danger bg-forge-danger-bg p-3 rounded-lg border border-forge-danger/20 text-center">
                      No GGUF, AWQ, or Safetensors files found. (Might be raw PyTorch format)
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2 max-h-64 overflow-y-auto custom-scrollbar pr-2">
                      {modelFiles.map((file, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-forge-surface/50 hover:bg-forge-surface p-3 rounded-lg border border-forge-border/50 group transition-colors">
                          <span className="font-mono text-sm text-forge-text/90 truncate mr-4">
                            {file.rfilename}
                          </span>
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleDownload(model.model_id, file); }}
                            className="shrink-0 bg-forge-bg hover:bg-forge-accent hover:text-white border border-forge-border text-forge-text-secondary px-4 py-1.5 rounded text-xs font-medium transition-all shadow-sm flex items-center gap-2"
                          >
                            <Icon icon={Download} size={14} /> Download
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>
          ))}
          {results.length === 0 && query.length > 2 && !loading && (
            <div className="text-center text-forge-text-muted mt-10">No models found for "{query}"</div>
          )}
        </div>
      </div>
    </div>
  );
}
