import { useState, useEffect } from 'react';
import { useUiStore } from '../store/uiStore';
import { useInferenceStore } from '../store/inference';
import { useModelsStore } from '../store/models';
import { useConfigStore } from '../store/configStore';
import {  Settings2, SlidersHorizontal, PanelRightClose, Cpu  } from 'lucide-react';
import { Icon } from './ui/Icon';
import { Badge } from './ui/Badge';
import { EmptyState } from './ui/EmptyState';
import { invoke } from '@tauri-apps/api/core';

interface EngineRecommendation {
  primary: string;
  score: number;
  reason: string;
  oom_risk: string;
}

export function RightInspector() {
  const { inspectorOpen, toggleInspector } = useUiStore();
  const { config: infConfig, setConfig } = useInferenceStore();
  const { models, scanModels } = useModelsStore();
  const { config: appConfig } = useConfigStore();

  useEffect(() => {
    if (appConfig?.storage.models_directory) {
      scanModels(appConfig.storage.models_directory);
    }
  }, [appConfig?.storage.models_directory, scanModels]);

  const [engineRec, setEngineRec] = useState<EngineRecommendation | null>(null);
  const [isEditingSystemPrompt, setIsEditingSystemPrompt] = useState(false);
  const [tempPrompt, setTempPrompt] = useState(infConfig.system_prompt);

  useEffect(() => {
    if (infConfig.modelPath) {
      invoke<EngineRecommendation>('suggest_engine', {
        modelPath: infConfig.modelPath
      }).then(setEngineRec).catch(console.error);
    } else {
      setEngineRec(null);
    }
  }, [infConfig.modelPath]);

  if (!inspectorOpen) return null;

  return (
    <div className="w-80 bg-forge-bg border-l border-forge-border flex flex-col h-full shrink-0 z-40 overflow-y-auto custom-scrollbar">
      {/* Header */}
      <div className="h-14 border-b border-forge-border flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-2 text-forge-text font-semibold text-sm">
          <Icon icon={Settings2} size={18} />
          <span>Configuration</span>
        </div>
        <button onClick={toggleInspector} className="text-forge-text-muted hover:text-forge-text transition-colors">
          <Icon icon={PanelRightClose} size={18} />
        </button>
      </div>

      <div className="p-6 flex flex-col gap-8">
        {/* Model Selection */}
        {/* Model Selection & Metadata Inspector */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] font-bold text-forge-text-muted uppercase tracking-widest flex items-center gap-2">
            <Icon icon={Cpu} size={12} /> Loaded Weights
          </label>
          
          {/* Premium Select Wrapper */}
          <div className="relative group">
            <select 
              value={infConfig.modelPath}
              onChange={(e) => setConfig({ ...infConfig, modelPath: (e.target as HTMLSelectElement).value })}
              className="appearance-none w-full bg-forge-surface-2 border border-forge-border hover:border-forge-accent/50 rounded-xl p-3 pl-4 pr-10 text-sm text-forge-text font-medium outline-none focus:border-forge-accent focus:ring-2 focus:ring-forge-accent/20 transition-all cursor-pointer backdrop-blur-md"
            >
              <option value="" disabled className="bg-forge-bg text-forge-text-muted">Initialize Inference Engine...</option>
              {models.map(m => (
                <option key={m.path} value={m.path} className="bg-forge-bg text-forge-text py-2">
                  {m.name} ({(m.size_mb / 1024).toFixed(1)} GB)
                </option>
              ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-forge-text-muted group-hover:text-forge-accent transition-colors">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
            </div>
          </div>

          {/* Metadata Badges (Stickers) - THE LM STUDIO KILLER FEATURE */}
          {infConfig.modelPath ? (() => {
            const activeModel = models.find(m => m.path === infConfig.modelPath);
            if (!activeModel) return null;
            
            return (
              <div className="flex flex-wrap gap-2 mt-1 animate-in fade-in slide-in-from-top-2 duration-300">
                <Badge color="blue">{activeModel.architecture.toUpperCase()}</Badge>
                <Badge color="purple" uppercase>{activeModel.quant_label || 'GGUF'}</Badge>
                <Badge color="emerald">~{(activeModel.size_mb * 1.2 / 1024).toFixed(1)} GB VRAM</Badge>
                <Badge color="amber">{activeModel.layer_count} Layers</Badge>
                <Badge color="zinc">{activeModel.embedding_length} Embed</Badge>
                {activeModel.chat_template && (
                  <Badge color="blue">Chat Template</Badge>
                )}
              </div>
            );
          })() : (
            <EmptyState />
          )}
        </div>

        {/* Engine Telemetry Badge */}
        {engineRec ? (
          <div className="flex flex-col gap-2">
            <span className="text-xs font-semibold text-forge-text-muted uppercase tracking-widest">
              Engine Recommendation
            </span>
            <div className="bg-forge-surface/50 border border-forge-accent/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-forge-accent">
                  {engineRec.primary}
                </span>
                <span className="text-[10px] font-mono text-forge-text-secondary bg-forge-bg px-2 rounded-md">
                  Score: {engineRec.score}
                </span>
              </div>
              <p className="text-[10px] text-forge-text-muted mt-2 mb-2 leading-relaxed">
                {engineRec.reason}
              </p>
              <Badge color={engineRec.oom_risk === 'High' ? 'red' : engineRec.oom_risk === 'Medium' ? 'amber' : 'emerald'}>
                OOM Risk: {engineRec.oom_risk}
              </Badge>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-forge-text-muted uppercase tracking-widest">Engine Status</span>
              <div className="bg-forge-surface/50 border border-forge-border/50 rounded-lg p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-forge-text-muted" />
                  <span className="text-sm font-medium text-forge-text-muted">Awaiting Selection</span>
                </div>
              </div>
          </div>
        )}

        {/* Hyperparameters */}
        <div className="flex flex-col gap-4">
          <label className="text-xs font-semibold text-forge-text-muted uppercase tracking-wider flex items-center gap-2">
            <Icon icon={SlidersHorizontal} size={14} /> Hyperparameters
          </label>
          
          <div className="flex flex-col gap-2">
            <div className="flex justify-between text-xs text-forge-text/70">
              <span>Max Tokens</span>
              <span>{infConfig.max_tokens}</span>
            </div>
            <input 
              type="range" 
              min="128" max="8192" step="128" 
              value={infConfig.max_tokens}
              onChange={(e) => setConfig({ max_tokens: parseInt((e.target as any).value) })}
              className="cockpit-slider w-full"
            />
            <div className="flex justify-between text-xs text-forge-text/70 mt-2">
              <span>Temperature</span>
              <span>{infConfig.temperature.toFixed(2)}</span>
            </div>
            <input 
              type="range" 
              min="0" max="2" step="0.05" 
              value={infConfig.temperature}
              onChange={(e) => setConfig({ temperature: parseFloat((e.target as any).value) })}
              className="cockpit-slider w-full"
            />
            <div className="flex justify-between text-xs text-forge-text/70 mt-2">
              <span>Top-P</span>
              <span>{infConfig.top_p.toFixed(2)}</span>
            </div>
            <input 
              type="range" 
              min="0.1" max="1.0" step="0.05" 
              value={infConfig.top_p}
              onChange={(e) => setConfig({ top_p: parseFloat((e.target as any).value) })}
              className="cockpit-slider w-full"
            />
            
            <div className="flex justify-between text-xs text-forge-text/70 mt-2">
              <span>Top-K</span>
              <span>{infConfig.top_k}</span>
            </div>
            <input 
              type="range" 
              min="1" max="100" step="1" 
              value={infConfig.top_k}
              onChange={(e) => setConfig({ top_k: parseInt((e.target as any).value) })}
              className="cockpit-slider w-full"
            />
            
            <div className="flex justify-between text-xs text-forge-text/70 mt-2">
              <span>Repetition Penalty</span>
              <span>{infConfig.repeat_penalty.toFixed(2)}</span>
            </div>
            <input 
              type="range" 
              min="1.0" max="2.0" step="0.05" 
              value={infConfig.repeat_penalty}
              onChange={(e) => setConfig({ repeat_penalty: parseFloat((e.target as any).value) })}
              className="cockpit-slider w-full"
            />
          </div>
        </div>

        {/* System Prompt Capsule */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-semibold text-forge-text-muted uppercase tracking-widest">System Prompt</label>
          {isEditingSystemPrompt ? (
            <textarea
              autoFocus
              value={tempPrompt}
              onChange={(e) => setTempPrompt((e.target as any).value)}
              onBlur={() => {
                setConfig({ system_prompt: tempPrompt });
                setIsEditingSystemPrompt(false);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setTempPrompt(infConfig.system_prompt);
                  setIsEditingSystemPrompt(false);
                }
              }}
              className="bg-forge-surface-2 border border-forge-accent/50 rounded-lg p-3 text-sm text-forge-text font-mono w-full min-h-[120px] outline-none resize-y custom-scrollbar shadow-inner"
            />
          ) : (
            <button
              onClick={() => { setTempPrompt(infConfig.system_prompt); setIsEditingSystemPrompt(true); }}
              className="bg-forge-surface/50 hover:bg-forge-surface border border-forge-border/50 hover:border-forge-border rounded-lg p-3 text-sm text-forge-text/80 text-left transition-all group flex flex-col gap-1 shadow-sm"
            >
              <span className="font-mono text-[10px] text-forge-accent uppercase tracking-wider">Persona: Click to Edit</span>
              <span className="text-xs text-forge-text-muted line-clamp-3">{infConfig.system_prompt}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
