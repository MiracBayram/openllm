import { useEffect, useRef } from 'react';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

export function useTauriEvent<T>(eventName: string, handler: (event: T) => void) {
  const savedHandler = useRef(handler);

  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    let unlisten: UnlistenFn | undefined;
    let isMounted = true;

    listen<T>(eventName, (event) => {
      if (isMounted) {
        savedHandler.current(event.payload);
      }
    }).then((unlistenFn) => {
      unlisten = unlistenFn;
    });

    return () => {
      isMounted = false;
      if (unlisten) {
        unlisten();
      }
    };
  }, [eventName]);
}
