export function calculateOOMRisk(
  usedVRAM: number,
  totalVRAM: number
): 'Safe' | 'Marginal' | 'Critical' {
  if (totalVRAM === 0) return 'Safe';
  const percentage = (usedVRAM / totalVRAM) * 100;
  
  if (percentage >= 95) return 'Critical';
  if (percentage >= 85) return 'Marginal';
  return 'Safe';
}
