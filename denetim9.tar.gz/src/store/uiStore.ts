import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UiState {
  activeTab: 'chat' | 'hub' | 'server' | 'settings';
  setActiveTab: (tab: 'chat' | 'hub' | 'server' | 'settings') => void;
  inspectorOpen: boolean;
  toggleInspector: () => void;
  onboardingComplete: boolean;
  setOnboardingComplete: (val: boolean) => void;
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      activeTab: 'chat',
      setActiveTab: (tab) => set({ activeTab: tab }),
      inspectorOpen: false, // Default false as requested
      toggleInspector: () => set((state) => ({ inspectorOpen: !state.inspectorOpen })),
      onboardingComplete: false,
      setOnboardingComplete: (val) => set({ onboardingComplete: val })
    }),
    {
      name: 'forge-ui-storage'
    }
  )
);
