import { create } from 'zustand';
import { useTauriEvent } from '../hooks/useTauriEvent';
import { useHardwareStore } from './hardware';
import { calculateOOMRisk } from '../utils/oomCalculator';

interface TelemetryState {
  tps: number;
  vramUsedMb: number;
  oomRisk: 'Safe' | 'Marginal' | 'High';
  updateStats: (payload: { tps: number; vramUsedMb: number; oomRisk: string }) => void;
}

export const useTelemetryStore = create<TelemetryState>((set) => ({
  tps: 0,
  vramUsedMb: 0,
  oomRisk: 'Safe',
  updateStats: (payload) => set({ 
    tps: payload.tps, 
    vramUsedMb: payload.vramUsedMb, 
    oomRisk: payload.oomRisk as any 
  }),
}));

export function useTelemetryHUD() {
  const tps = useTelemetryStore((state) => state.tps);
  const vramUsedMb = useTelemetryStore((state) => state.vramUsedMb);
  const oomRisk = useTelemetryStore((state) => state.oomRisk);

  useTauriEvent<{tokens_per_sec: number, vram_used_mb: number}>('forge://stats', (event) => {
    const tps = event.tokens_per_sec;
    const vramUsedMb = event.vram_used_mb;
    
    const profile = useHardwareStore.getState().profile;
    const totalVram = profile ? profile.gpus.reduce((acc, g) => acc + g.vram_mb, 0) : 8192;
    const oomRisk = calculateOOMRisk(vramUsedMb, totalVram);

    useTelemetryStore.getState().updateStats({ 
      tps: parseFloat(tps.toFixed(2)), 
      vramUsedMb, 
      oomRisk 
    });
  });

  return { tps, vramUsedMb, oomRisk };
}
