import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'error';
  content: string;
}

interface ChatState {
  messages: Message[];
  activeMessage: Message | null;
  addMessage: (msg: Message) => void;
  setActiveMessage: (msg: Message) => void;
  appendContentToActiveMessage: (content: string) => void;
  commitActiveMessage: () => void;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>()(
  persist(
    (set) => ({
      messages: [],
      activeMessage: null,
      addMessage: (msg) => set((state) => {
        const newMessages = [...state.messages, msg];
        return { messages: newMessages.slice(-500) };
      }),
      setActiveMessage: (msg) => set({ activeMessage: msg }),
      appendContentToActiveMessage: (content) => set((state) => {
        if (!state.activeMessage) return state;
        return { activeMessage: { ...state.activeMessage, content: state.activeMessage.content + content } };
      }),
      commitActiveMessage: () => set((state) => {
        if (!state.activeMessage) return state;
        const newMessages = [...state.messages, state.activeMessage];
        return { 
          messages: newMessages.slice(-500),
          activeMessage: null
        };
      }),
      clearMessages: () => set({ messages: [], activeMessage: null }),
    }),
    {
      name: 'forge-chat-storage',
      // Sadece messages dizisini sakla, activeMessage transient (kalıcı değil)
      partialize: (state) => ({
        messages: state.messages.map(m => ({
          id: m.id,
          role: m.role,
          content: m.content
        }))
      })
    }
  )
);
