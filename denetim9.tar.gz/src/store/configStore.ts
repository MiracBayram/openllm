import { create } from 'zustand';
import { load } from '@tauri-apps/plugin-store';
import { invoke } from '@tauri-apps/api/core';

let store: any;
export interface AppConfig {
  ui: {
    theme: string;
    sidebar_collapsed: boolean;
  };
  hardware: {
    vram_limit_mb: number;
    cpu_threads: number;
  };
  storage: {
    models_directory: string;
    auto_preload_last_model: boolean;
  };
  network: {
    lan_server_enabled: boolean;
    api_key_uuid: string;
  };
}

const DEFAULT_CONFIG: AppConfig = {
  ui: {
    theme: 'dracula',
    sidebar_collapsed: false,
  },
  hardware: {
    vram_limit_mb: 8192,
    cpu_threads: 8,
  },
  storage: {
    models_directory: '', // Resolved at runtime
    auto_preload_last_model: true,
  },
  network: {
    lan_server_enabled: false,
    api_key_uuid: '',
  },
};

interface ConfigState {
  config: AppConfig | null;
  isLoaded: boolean;
  loadConfig: () => Promise<void>;
  updateConfig: (partial: Partial<AppConfig>) => Promise<void>;
}

export const useConfigStore = create<ConfigState>((set) => ({
  config: null,
  isLoaded: false,
  
  loadConfig: async () => {
    try {
      if (!store) {
        store = await load('.forge_config.json', { autoSave: false } as any);
      }
      const keys = await store.keys();
      if (keys.length === 0) {
        // Resolve cross-platform default dir
        try {
          const modelsDir = await invoke<string>('get_models_dir');
          DEFAULT_CONFIG.storage.models_directory = modelsDir;
        } catch(e) {
          console.warn('Failed to resolve models dir from rust', e);
        }

        // Initialize with default config
        for (const [key, value] of Object.entries(DEFAULT_CONFIG) as [keyof AppConfig, any][]) {
          await store.set(key, value);
        }
        await store.save();
        set({ config: DEFAULT_CONFIG, isLoaded: true });
        
        // Apply initial theme
        document.documentElement.setAttribute('data-theme', DEFAULT_CONFIG.ui.theme);
      } else {
        const ui = await store.get('ui') as any || DEFAULT_CONFIG.ui;
        const hardware = await store.get('hardware') as any || DEFAULT_CONFIG.hardware;
        const storage = await store.get('storage') as any || DEFAULT_CONFIG.storage;
        const network = await store.get('network') as any || DEFAULT_CONFIG.network;
        
        const loadedConfig = { ui, hardware, storage, network };
        set({ config: loadedConfig, isLoaded: true });
        
        document.documentElement.setAttribute('data-theme', loadedConfig.ui.theme);
      }
    } catch (error) {
      console.error('Failed to load config', error);
      set({ config: DEFAULT_CONFIG, isLoaded: true });
    }
  },

  updateConfig: async (partial: Partial<AppConfig>) => {
    // 1. Optimistic UI update (Synchronous)
    let newConfig: AppConfig;
    set((state) => {
      if (!state.config) return state;
      newConfig = { ...state.config, ...partial };
      
      // Check if theme changed
      if (partial.ui?.theme) {
        document.documentElement.setAttribute('data-theme', partial.ui.theme);
      }
      
      return { config: newConfig };
    });

    // 2. Async disk save
    if (partial.ui) await store.set('ui', partial.ui);
    if (partial.hardware) await store.set('hardware', partial.hardware);
    if (partial.storage) await store.set('storage', partial.storage);
    if (partial.network) await store.set('network', partial.network);
    
    await store.save();
  }
}));
