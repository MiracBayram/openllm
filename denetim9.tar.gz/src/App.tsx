import { useEffect, useState } from 'react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { invoke } from '@tauri-apps/api/core';
import { HardwareHUD } from './components/HardwareHUD';
import { ChatView } from './components/ChatView';
import { TitleBar } from './components/TitleBar';
import { Sidebar } from './components/Sidebar';
import { RightInspector } from './components/RightInspector';
import { HubView } from './components/HubView';
import { ServerView } from './components/ServerView';
import { SettingsView } from './components/SettingsView';
import { OnboardingWizard } from './components/OnboardingWizard';
import { useUiStore } from './store/uiStore';
import { useConfigStore } from './store/configStore';
import './App.css';

function App() {
  const activeTab = useUiStore((s) => s.activeTab);
  const onboardingComplete = useUiStore((s) => s.onboardingComplete);
  const isLoaded = useConfigStore((s) => s.isLoaded);
  const loadConfig = useConfigStore((s) => s.loadConfig);

  const [isShuttingDown, setIsShuttingDown] = useState(false);

  useEffect(() => {
    loadConfig();

    // Red Flag 4: Tauri Graceful Shutdown
    const unlistenPromise = getCurrentWindow().onCloseRequested(async (event) => {
      // Prevent immediate close
      event.preventDefault();
      setIsShuttingDown(true);
      
      try {
        await invoke('stop_inference'); // Send signal to kill engine
        // Add artificial delay for UX to show the shutdown screen
        setTimeout(async () => {
          await getCurrentWindow().destroy();
        }, 800);
      } catch (e) {
        await getCurrentWindow().destroy();
      }
    });

    return () => {
      unlistenPromise.then(unlisten => unlisten());
    };
  }, [loadConfig]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case '1': e.preventDefault(); useUiStore.getState().setActiveTab('chat'); break;
          case '2': e.preventDefault(); useUiStore.getState().setActiveTab('hub'); break;
          case '3': e.preventDefault(); useUiStore.getState().setActiveTab('server'); break;
          case '4': e.preventDefault(); useUiStore.getState().setActiveTab('settings'); break;
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (isShuttingDown) {
    return (
      <div className="flex flex-col w-screen h-screen items-center justify-center bg-forge-bg text-forge-text font-sans">
        <div className="flex flex-col items-center gap-4 animate-in fade-in zoom-in duration-300">
          <div className="w-12 h-12 rounded-full border-t-2 border-forge-accent animate-spin" />
          <h2 className="text-xl font-medium tracking-tight">Shutting down engine...</h2>
          <p className="text-sm text-forge-text-muted">Safely flushing memory</p>
        </div>
      </div>
    );
  }

  if (!onboardingComplete) {
    return (
      <div className="flex flex-col w-screen h-screen overflow-hidden font-sans select-none">
        <TitleBar />
        <div className="flex flex-1 min-h-0 relative">
          <OnboardingWizard />
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return <div className="flex w-screen h-screen items-center justify-center bg-forge-bg text-forge-text">Yükleniyor...</div>;
  }

  return (
    <div className="flex flex-col w-screen h-screen bg-forge-bg text-forge-text overflow-hidden font-sans selection:bg-forge-accent/30">
      <TitleBar />
      <div className="flex flex-1 min-h-0 relative">
        <Sidebar />
        
        <main className="flex-1 flex flex-col relative h-full bg-forge-bg">
          {activeTab === 'chat' && <HardwareHUD />}
          
          <div className="flex-1 relative overflow-hidden flex">
            {activeTab === 'chat' && <ChatView />}
            {activeTab === 'hub' && <HubView />}
            {activeTab === 'server' && <ServerView />}
            {activeTab === 'settings' && <SettingsView />}
          </div>
        </main>
        
        {activeTab === 'chat' && <RightInspector />}
      </div>
    </div>
  );
}

export default App;
