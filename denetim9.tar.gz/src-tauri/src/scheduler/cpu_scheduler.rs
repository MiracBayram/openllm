use crate::profiler::HardwareProfile;

// DENETÇİ NOTU: Hyper-Threading devre dışı, sadece Fiziksel P-Core'lar kullanılır.
pub fn get_optimal_thread_count(hw_profile: &HardwareProfile) -> u32 {
    // Fiziksel P-Core sayısını al (Hyper-Threading hariç)
    // Şimdilik rust tarafındaki CpuInfo struct'ına göre physical_cores kullanılır
    let p_cores = hw_profile.cpu.physical_cores; 
    
    if p_cores > 0 {
        p_cores
    } else {
        hw_profile.cpu.logical_cores
    }
}

// Linux için sched_setaffinity ile Pinning (Sadece İzole Çekirdekler)
#[cfg(target_os = "linux")]
pub fn pin_threads_to_p_cores(p_cores: u32) {
    use nix::sched::{sched_setaffinity, CpuSet};
    use nix::unistd::Pid;

    let mut cpuset = CpuSet::new();
    for i in 0..p_cores {
        let _ = cpuset.set(i as usize);
    }
    
    // Sadece mevcut thread'i pin'le, alt thread'ler bunu inherit eder.
    let _ = sched_setaffinity(Pid::from_raw(0), &cpuset);
}

#[cfg(not(target_os = "linux"))]
pub fn pin_threads_to_p_cores(_p_cores: u32) {
    // Other OS pinning not implemented yet.
}
