use tauri::{Manager, Emitter};
use tokio::sync::{Mutex, RwLock};

pub mod engines;
pub mod process;
pub mod profiler;
pub mod router;
pub mod commands;
pub mod hub;
pub mod server;
pub mod scheduler;

use process::spawner::EngineHandle;
use profiler::HardwareProfile;

pub struct AppState {
    pub hardware_profile: RwLock<Option<HardwareProfile>>,
    pub active_handle: Mutex<Option<EngineHandle>>,
    pub active_mmap: Mutex<Option<memmap2::Mmap>>,
    pub server_cancel_token: Mutex<Option<tokio_util::sync::CancellationToken>>,
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {

    tauri::Builder::default()
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_store::Builder::new().build())
        .plugin(tauri_plugin_os::init())
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            // Generate UUID for LAN Auth via AppData
            if let Ok(app_data_dir) = app.path().app_data_dir() {
                let models_dir = app_data_dir.join("models");
                if !models_dir.exists() {
                    let _ = std::fs::create_dir_all(&models_dir);
                }
                let key_path = app_data_dir.join(".api_key");
                if !key_path.exists() {
                    let key = uuid::Uuid::new_v4().to_string();
                    let _ = std::fs::write(&key_path, key);
                }
            }

            app.manage(AppState {
                hardware_profile: RwLock::new(None),
                active_handle: Mutex::new(None),
                active_mmap: Mutex::new(None),
                server_cancel_token: Mutex::new(None),
            });

            let app_handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                // Denetçi Kuralı: NVML Lock Contention önlemek için 10 saniyede bir (0.1Hz) polling
                let mut interval = tokio::time::interval(std::time::Duration::from_secs(10));
                loop {
                    interval.tick().await;
                    if let Ok(profile) = profiler::profile().await {
                        if let Some(state) = app_handle.try_state::<AppState>() {
                            let mut hp_lock = state.hardware_profile.write().await;
                            *hp_lock = Some(profile.clone());
                        }

                        let total_vram = profile.gpus.iter().map(|g| g.vram_mb).sum::<u64>();
                        let available_vram = profile.gpus.iter().map(|g| g.vram_available_mb).sum::<u64>();
                        let used_vram = total_vram.saturating_sub(available_vram);
                        
                        let total_ram = profile.memory.total_mb;
                        let available_ram = profile.memory.available_mb;
                        let used_ram = total_ram.saturating_sub(available_ram);

                        let _ = app_handle.emit("forge://hardware_tick", serde_json::json!({
                            "vram_used": used_vram,
                            "vram_total": total_vram,
                            "ram_used": used_ram,
                            "ram_total": total_ram
                        }));
                    }
                }
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::get_hardware_profile,
            commands::list_models,
            commands::suggest_engine,
            commands::start_inference,
            commands::stop_inference,
            commands::start_local_server,
            commands::stop_local_server,
            commands::get_server_status,
            commands::search_hub_models,
            commands::start_download,
            commands::initialize_engines,
            commands::refresh_engines,
            commands::get_models_dir,
            commands::window_close,
            commands::window_minimize,
            commands::window_maximize,
            commands::window_start_dragging
        ])
        .build(tauri::generate_context!())
        .expect("error while building tauri application")
        .run(|app_handle, event| match event {
            tauri::RunEvent::ExitRequested { .. } => {
                tracing::info!("OS Kapanış Sinyali (RunEvent::ExitRequested) alındı, zombiler temizleniyor...");
                if let Some(state) = app_handle.try_state::<AppState>() {
                    if let Ok(mut handle) = state.active_handle.try_lock() {
                        if let Some(h) = handle.take() {
                            tracing::info!("Aktif inference kapatılıyor...");
                            drop(h);
                        }
                    }
                    if let Ok(mut token_lock) = state.server_cancel_token.try_lock() {
                        if let Some(token) = token_lock.take() {
                            tracing::info!("Axum sunucusu kapatılıyor...");
                            token.cancel();
                        }
                    }
                }
            }
            _ => {}
        });
}
