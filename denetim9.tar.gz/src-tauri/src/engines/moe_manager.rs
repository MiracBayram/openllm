use memmap2::MmapOptions;
use std::fs::File;
use std::path::Path;

// DENETÇİ NOTU: Motorun kendi predictor'ına güvenilir. Rust sadece mmap yönetir.
pub fn prepare_moe_model(path: &Path) -> Result<memmap2::Mmap, String> {
    let file = File::open(path).map_err(|e| e.to_string())?;
    
    // Dosyayı mmap et, ancak OS'a "Random Access" yapacağımızı söyle.
    // Bu, OS'un gereksiz read-ahead yapmasını engeller.
    let mmap = unsafe { 
        MmapOptions::new()
            .populate() // Sayfaları önceden page cache'e yükle
            .map(&file)
            .map_err(|e| e.to_string())? 
    };
    
    // madvise(MADV_RANDOM) - MoE için kritiktir.
    #[cfg(target_os = "linux")]
    unsafe {
        libc::madvise(
            mmap.as_ptr() as *mut libc::c_void,
            mmap.len(),
            libc::MADV_RANDOM,
        );
    }
    
    Ok(mmap)
}
