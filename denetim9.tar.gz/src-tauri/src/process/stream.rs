use crate::engines::EngineEvent;

#[derive(serde::Deserialize)]
struct LlamaLine {
    #[serde(rename = "type")]
    kind: String,
    content: Option<String>,
    tokens_predicted: Option<u32>,
    generation_time_ms: Option<u64>,
}

pub fn parse_llamacpp_line(line: &str) -> Option<EngineEvent> {
    let parsed: LlamaLine = serde_json::from_str(line).ok()?;
    match parsed.kind.as_str() {
        "token" => Some(EngineEvent::Token(parsed.content?)),
        "generation_complete" => Some(EngineEvent::Done {
            tokens_generated: parsed.tokens_predicted.unwrap_or(0),
            duration_ms: parsed.generation_time_ms.unwrap_or(0),
        }),
        _ => None,
    }
}

pub async fn stream_llamacpp(
    stdout: tokio::process::ChildStdout,
    tx: tokio::sync::mpsc::Sender<EngineEvent>,
) {
    use tokio::io::{AsyncBufReadExt, BufReader};
    let mut reader = BufReader::new(stdout).lines();
    while let Ok(Some(line)) = reader.next_line().await {
        if let Some(event) = parse_llamacpp_line(&line) {
            // Drop frame if UI is too slow to prevent OOM
            if let Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) = tx.try_send(event) {
                break;
            }
        }
    }
}
