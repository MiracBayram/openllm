use std::path::Path;
use std::fs::File;
use crate::profiler::HardwareProfile;

#[derive(Debug, PartialEq)]
pub enum ModelFormat {
    GGUF,
    AWQ,
    GPTQ,
    Safetensors,
    Unknown,
}

pub struct ModelMetadata {
    pub format: ModelFormat,
    pub magic_bytes_valid: bool,
    pub architecture: Option<String>,
}

impl ModelMetadata {
    pub fn is_valid_magic_bytes(&self) -> bool {
        self.magic_bytes_valid
    }
}

pub enum EngineDecision {
    LlamaCpp,
    LMDeploy,
    VLLM,
    HardRefusal(String),
}

use std::io::Read;

pub fn parse_model_metadata(file_path: &Path) -> Result<ModelMetadata, String> {
    let mut file = File::open(file_path).map_err(|e| format!("Failed to open file: {}", e))?;
    
    let mut magic = [0u8; 4];
    if file.read_exact(&mut magic).is_err() {
        return Ok(ModelMetadata { format: ModelFormat::Unknown, magic_bytes_valid: false, architecture: None });
    }
    
    let (format, valid) = if magic == [0x47, 0x47, 0x55, 0x46] {
        (ModelFormat::GGUF, true)
    } else {
        // Simple fallback to detect .safetensors extension for AWQ/GPTQ if magic byte parsing is complex
        // In real Elite code, we would parse safetensors JSON header length here.
        let ext = file_path.extension().and_then(|s| s.to_str()).unwrap_or("");
        if ext == "safetensors" {
            // Assume valid safetensors for now
            let path_str = file_path.to_string_lossy().to_lowercase();
            if path_str.contains("awq") {
                (ModelFormat::AWQ, true)
            } else if path_str.contains("gptq") {
                (ModelFormat::GPTQ, true)
            } else {
                (ModelFormat::Safetensors, true)
            }
        } else {
            (ModelFormat::Unknown, false)
        }
    };

    Ok(ModelMetadata {
        format,
        magic_bytes_valid: valid,
        architecture: None, // Could parse GGUF KV pairs here in the future
    })
}

pub fn predict_best_engine(
    file_metadata: &ModelMetadata,
    hardware: &HardwareProfile,
) -> EngineDecision {
    if !file_metadata.is_valid_magic_bytes() {
        return EngineDecision::HardRefusal("Invalid model file (Corrupted Header / Unknown Magic Bytes).".into());
    }

    let has_nvidia = hardware.gpus.iter().any(|g| matches!(g.vendor, crate::profiler::gpu::GpuVendor::Nvidia));
    let has_amd = hardware.gpus.iter().any(|g| matches!(g.vendor, crate::profiler::gpu::GpuVendor::Amd));
    let is_mac = cfg!(target_os = "macos");

    match file_metadata.format {
        ModelFormat::GGUF => {
            if has_nvidia || has_amd || is_mac || hardware.gpus.is_empty() {
                EngineDecision::LlamaCpp
            } else {
                EngineDecision::HardRefusal("Unsupported hardware architecture for GGUF.".into())
            }
        },
        ModelFormat::AWQ | ModelFormat::GPTQ => {
            if has_nvidia {
                EngineDecision::LMDeploy
            } else {
                EngineDecision::HardRefusal("AWQ/GPTQ formats require NVIDIA CUDA. Please download a GGUF format for your hardware.".into())
            }
        },
        ModelFormat::Safetensors => {
            if has_nvidia || has_amd {
                EngineDecision::VLLM // Generic safetensors usually runs well on vLLM
            } else {
                EngineDecision::HardRefusal("Raw Safetensors models require discrete GPUs (CUDA/ROCm).".into())
            }
        },
        _ => EngineDecision::HardRefusal("Unsupported model format.".into())
    }
}
