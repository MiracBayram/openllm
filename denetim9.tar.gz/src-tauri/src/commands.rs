use serde::Deserialize;
use tauri::{AppHandle, Emitter, Manager, State};

use crate::engines;
use crate::profiler::{profile, HardwareProfile};
use crate::router::{decision_tree::EngineRecommendation, ModelInfo};
use crate::AppState;

#[tauri::command]
pub async fn get_hardware_profile(state: State<'_, AppState>) -> Result<HardwareProfile, String> {
    let mut hp_lock = state.hardware_profile.write().await;
    if let Some(ref hp) = *hp_lock {
        return Ok(hp.clone());
    }

    let hp = profile().await.map_err(|e| e.to_string())?;
    *hp_lock = Some(hp.clone());
    Ok(hp)
}

#[tauri::command]
pub async fn list_models(dir: String) -> Result<Vec<ModelInfo>, String> {
    let mut models = Vec::new();
    if let Ok(entries) = std::fs::read_dir(&dir) {
        for entry in entries.filter_map(|e| e.ok()) {
            let path = entry.path();
            if path.extension().is_some_and(|ext| ext == "gguf") {
                let mut size_mb = 0;
                let mut layer_count = 32;
                let mut architecture = "llama".to_string();
                let mut quant_label = "Q4_K_M".to_string();
                let mut chat_template = None;
                let mut attention_head_count = 32;
                let mut attention_head_count_kv = None;
                let mut embedding_length = 4096;

                if let Ok(meta) = crate::profiler::gguf::read_gguf_meta(&path) {
                    size_mb = meta.file_size_mb;
                    layer_count = meta.layer_count;
                    architecture = meta.architecture;
                    quant_label = meta.quant_label;
                    chat_template = meta.chat_template;
                    attention_head_count = meta.attention_head_count;
                    attention_head_count_kv = meta.attention_head_count_kv;
                    embedding_length = meta.embedding_length;
                } else if let Ok(metadata) = entry.metadata() {
                    size_mb = metadata.len() / 1024 / 1024;
                }

                models.push(ModelInfo {
                    path: path.to_string_lossy().to_string(),
                    name: entry.file_name().to_string_lossy().to_string(),
                    size_mb,
                    layer_count,
                    architecture,
                    quant_label,
                    chat_template,
                    attention_head_count,
                    attention_head_count_kv,
                    embedding_length,
                });
            }
        }
    }
    Ok(models)
}

#[tauri::command]
pub async fn suggest_engine(
    model_path: String,
    state: State<'_, AppState>,
) -> Result<EngineRecommendation, String> {
    let profile = get_hardware_profile(state).await?;
    let model = crate::router::ModelInfo::from_path(&std::path::PathBuf::from(&model_path))
        .unwrap_or_else(|_| ModelInfo {
            path: model_path.clone(),
            name: std::path::Path::new(&model_path)
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .to_string(),
            size_mb: 4096,
            layer_count: 32,
            architecture: "llama".to_string(),
            quant_label: "Q4".to_string(),
            chat_template: None,
            attention_head_count: 32,
            attention_head_count_kv: None,
            embedding_length: 4096,
        });

    let registry: Vec<Box<dyn crate::engines::EngineAdapter>> =
        vec![Box::new(engines::llamacpp::LlamaCppAdapter::new())];

    let recommendation = crate::router::decision_tree::select_engine(&profile, &model, &registry).await;
    Ok(recommendation)
}

#[derive(Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct InferenceParams {
    pub temperature: f32,
    pub max_tokens: u32,
    pub top_p: Option<f32>,
    pub top_k: Option<u32>,
    pub repeat_penalty: Option<f32>,
    pub advanced_flags: Option<String>,
    pub prompt: Option<String>,
    pub system_prompt: Option<String>,
    pub messages: Option<Vec<ChatMessageInput>>,
}

#[derive(Deserialize, Clone)]
pub struct ChatMessageInput {
    pub role: String,
    pub content: String,
}

#[tauri::command(rename_all = "camelCase")]
pub async fn start_inference(
    model_path: String,
    params: InferenceParams,
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<(), String> {
    let prompt_text = params.prompt.clone().unwrap_or_default();
    let profile = {
        let lock = state.hardware_profile.read().await;
        lock.clone().ok_or("Donanım profili henüz hazır değil")?
    };

    let canonical_path = std::fs::canonicalize(&model_path).map_err(|e| format!("Geçersiz model yolu: {}", e))?;
    
    // Güvenlik Kalkanı: Path Traversal Koruması
    if let Ok(app_data) = app.path().app_data_dir() {
        let models_dir = app_data.join("models");
        if !canonical_path.starts_with(&models_dir) {
            return Err("Güvenlik İhlali: Model dizini dışındaki dosyalara erişim engellendi".to_string());
        }
    }
    
    // Strict GGUF Magic Validation (E1)
    if let Err(e) = crate::profiler::gguf::read_gguf_meta(&canonical_path) {
        let err_msg = format!("HARD REFUSAL: Geçersiz veya bozuk GGUF dosyası (Magic Number eşleşmedi). Güvenlik sebebiyle başlatılamaz. Detay: {:?}", e);
        let _ = app.emit("forge://error", &err_msg);
        return Err(err_msg);
    }

    let model = crate::router::ModelInfo::from_path(&canonical_path)
        .map_err(|e| e.to_string())?;

    let registry = crate::engines::build_engine_registry();
    let recommendation =
        crate::router::decision_tree::select_engine(&profile, &model, &registry).await;

    tracing::info!(
        engine = recommendation.primary,
        score = recommendation.score,
        oom_risk = ?recommendation.oom_risk,
        "Motor seçildi"
    );

    if matches!(
        recommendation.oom_risk,
        crate::router::decision_tree::OomRisk::High
    ) {
        let msg = format!("HARD REFUSAL: RAM/VRAM yetersiz veya yasaklı kuantizasyon. Sistem kilitlenmesini önlemek için işlem reddedildi. Reason: {}", recommendation.reason);
        let _ = app.emit("forge://error", &msg);
        return Err(msg);
    }

    let adapter = registry
        .iter()
        .find(|a| a.name() == recommendation.primary)
        .ok_or("Motor bulunamadı")?;
    let binary_name = match recommendation.primary.as_str() {
        "llama.cpp" => "llama-server",
        "vLLM" => "python",
        "LMDeploy" => "lmdeploy",
        "PowerInfer-2" => "powerinfer",
        _ => "llama-server",
    };
    let mut binary_path = std::path::PathBuf::from(binary_name);
    let exe_ext = std::env::consts::EXE_EXTENSION;
    if !exe_ext.is_empty() {
        binary_path.set_extension(exe_ext);
    }

    let mut final_flags = recommendation.flags;
    if let Some(user_flags) = params.advanced_flags {
        let safe_args = crate::engines::flag_sanitizer::sanitize_advanced_flags(&user_flags);
        final_flags.extend(safe_args);
    }

    // Template Engine & Prompt Injection (C6)
    let messages = vec![
        crate::engines::template_engine::ChatMessage {
            role: "system".to_string(),
            content: params.system_prompt.clone().unwrap_or_else(|| "You are a helpful AI assistant.".to_string()),
        },
        crate::engines::template_engine::ChatMessage {
            role: "user".to_string(),
            content: prompt_text.clone(),
        }
    ];

    let final_prompt = if let Some(ref tmpl) = model.chat_template {
        crate::engines::template_engine::apply_chat_template(tmpl, &messages).unwrap_or(prompt_text.clone())
    } else {
        prompt_text.clone()
    };

    // If using a CLI tool that expects --prompt
    final_flags.push("--prompt".to_string());
    final_flags.push(final_prompt);

    let (tx, mut rx) = tokio::sync::mpsc::channel::<crate::engines::EngineEvent>(1024);
    let handle = adapter
        .spawn(binary_path, final_flags, tx)
        .await
        .map_err(|e| e.to_string())?;

    {
        let mut lock = state.active_handle.lock().await;
        *lock = Some(handle);
    }

    let app_clone = app.clone();
    tokio::spawn(async move {
        let mut token_buffer = String::with_capacity(1024);
        loop {
            let event_opt = if token_buffer.is_empty() {
                rx.recv().await
            } else {
                match tokio::time::timeout(std::time::Duration::from_millis(50), rx.recv()).await {
                    Ok(res) => res,
                    Err(_) => {
                        let _ = app_clone.emit("forge://token", &token_buffer);
                        token_buffer.clear();
                        continue;
                    }
                }
            };

            match event_opt {
                Some(event) => {
                    match event {
                        crate::engines::EngineEvent::Token(text) => {
                            token_buffer.push_str(&text);
                            let is_whitespace = text.chars().last().is_some_and(|c| c.is_whitespace());
                            if text.contains('\n') || (token_buffer.len() > 512 && is_whitespace) {
                                let _ = app_clone.emit("forge://token", &token_buffer);
                                token_buffer.clear();
                            }
                        }
                        crate::engines::EngineEvent::Done { tokens_generated, duration_ms } => {
                            if !token_buffer.is_empty() {
                                let _ = app_clone.emit("forge://token", &token_buffer);
                                token_buffer.clear();
                            }
                            let _ = app_clone.emit("forge://done", serde_json::json!({
                                "tokens": tokens_generated,
                                "duration_ms": duration_ms
                            }));
                            break;
                        }
                        crate::engines::EngineEvent::Error(msg) => {
                            let _ = app_clone.emit("forge://error", msg);
                            break;
                        }
                        crate::engines::EngineEvent::Stats { tokens_per_sec, vram_used_mb } => {
                            let _ = app_clone.emit("forge://stats", serde_json::json!({
                                "tokens_per_sec": tokens_per_sec,
                                "vram_used_mb": vram_used_mb
                            }));
                        }
                    }
                }
                None => break,
            }
        }
    });

    Ok(())
}

#[derive(serde::Serialize)]
pub struct ServerStatus {
    pub running: bool,
    pub port: Option<u16>,
}

#[tauri::command]
pub async fn get_server_status(state: tauri::State<'_, AppState>) -> Result<ServerStatus, String> {
    let token_lock = state.server_cancel_token.lock().await;
    let running = token_lock.is_some();
    Ok(ServerStatus {
        running,
        port: if running { Some(1234) } else { None },
    })
}

#[tauri::command(rename_all = "camelCase")]
pub async fn initialize_engines(engines: Vec<String>) -> Result<(), String> {
    tracing::info!("Engines initialized: {:?}", engines);
    Ok(())
}

#[tauri::command(rename_all = "camelCase")]
pub async fn refresh_engines() -> Result<(), String> {
    let mut cache = crate::router::decision_tree::get_engine_cache().write().await;
    cache.clear();
    tracing::info!("Engine availability cache cleared");
    Ok(())
}

#[tauri::command]
pub async fn get_models_dir(app: AppHandle) -> Result<String, String> {
    let app_data_dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let models_dir = app_data_dir.join("models");
    Ok(models_dir.to_string_lossy().to_string())
}

#[tauri::command]
pub async fn start_local_server(
    api_key: String,
    app: tauri::AppHandle,
    state: tauri::State<'_, AppState>,
) -> Result<u16, String> {
    let cancel_token = tokio_util::sync::CancellationToken::new();
    {
        let mut token_lock = state.server_cancel_token.lock().await;
        if token_lock.is_some() {
            return Err("Sunucu zaten çalışıyor.".to_string());
        }
        *token_lock = Some(cancel_token.clone());
    }

    crate::server::start_server(app, 1234, api_key, cancel_token).await
}

#[tauri::command]
pub async fn stop_local_server(
    state: tauri::State<'_, AppState>,
) -> Result<(), String> {
    let mut token_lock = state.server_cancel_token.lock().await;
    if let Some(token) = token_lock.take() {
        token.cancel();
        Ok(())
    } else {
        Err("Çalışan sunucu bulunamadı.".to_string())
    }
}

#[tauri::command]
pub async fn search_hub_models(query: String) -> Result<Vec<crate::hub::HubModel>, String> {
    crate::hub::search_models(&query).await
}

#[tauri::command]
pub async fn stop_inference(state: State<'_, AppState>) -> Result<(), String> {
    let mut lock = state.active_handle.lock().await;
    if let Some(mut handle) = lock.take() {
        handle.stop().await;
        tracing::info!("Inference durduruldu");
    }
    Ok(())
}

#[tauri::command]
pub async fn start_download(
    model_id: String,
    file_name: String,
    expected_sha256: String,
    app: AppHandle,
) -> Result<(), String> {
    let url = crate::hub::build_model_url(&model_id, &file_name)?;
    let app_data_dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let models_dir = app_data_dir.join("models");
    let target_path = models_dir.join(&file_name);

    let (tx, mut rx) = tokio::sync::mpsc::channel::<crate::hub::downloader::DownloadEvent>(100);
    let app_clone = app.clone();
    let model_id_clone = model_id.clone();
    let file_name_clone = file_name.clone();

    // Spawn progress listener
    tokio::spawn(async move {
        while let Some(progress) = rx.recv().await {
            let _ = app_clone.emit("forge://download::progress", serde_json::json!({
                "model_id": model_id_clone,
                "file_name": file_name_clone,
                "downloaded_bytes": progress.downloaded_bytes,
                "total_bytes": progress.total_bytes,
                "speed_bps": 0, // Mock for now, could be calculated
                "status": "Downloading"
            }));
        }
    });

    // Spawn download task
    tokio::spawn(async move {
        if let Err(e) = crate::hub::downloader::download_model_securely(&url, &target_path, &expected_sha256, tx).await {
            let _ = app.emit("forge://download::progress", serde_json::json!({
                "model_id": model_id,
                "file_name": file_name,
                "downloaded_bytes": 0,
                "total_bytes": 0,
                "speed_bps": 0,
                "status": format!("Error: {}", e)
            }));
        } else {
            let _ = app.emit("forge://download::progress", serde_json::json!({
                "model_id": model_id,
                "file_name": file_name,
                "downloaded_bytes": 100, // Or whatever signal means complete
                "total_bytes": 100,
                "speed_bps": 0,
                "status": "Completed"
            }));
        }
    });

    Ok(())
}

#[tauri::command]
pub fn window_close(window: tauri::Window) {
    let _ = window.close();
}

#[tauri::command]
pub fn window_minimize(window: tauri::Window) {
    let _ = window.minimize();
}

#[tauri::command]
pub fn window_maximize(window: tauri::Window) {
    if let Ok(true) = window.is_maximized() {
        let _ = window.unmaximize();
    } else {
        let _ = window.maximize();
    }
}

#[tauri::command]
pub fn window_start_dragging(window: tauri::Window) {
    let _ = window.start_dragging();
}
